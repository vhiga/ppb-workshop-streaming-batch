#!/usr/bin/env python

import os

from setuptools import setup


if __name__ == "__main__":
    # allow setup.py to run from another directory
    BASEDIR = os.path.dirname(__file__)
    BASEDIR and os.chdir(BASEDIR)
    setup()
