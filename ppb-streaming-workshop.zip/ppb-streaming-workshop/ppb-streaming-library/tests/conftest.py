import os

from pathlib import Path

import pytest


# REF: https://github.com/pytest-dev/pytest/issues/2393
def pytest_sessionfinish(session, exitstatus):
    # if all the tests are skipped, lets not fail the entire CI run
    if exitstatus == 5:
        session.exitstatus = 0


@pytest.fixture(scope="session")
def aws_credentials():
    os.environ["AWS_ACCESS_KEY_ID"] = "testing"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
    os.environ["AWS_SECURITY_TOKEN"] = "testing"
    os.environ["AWS_SESSION_TOKEN"] = "testing"


@pytest.fixture(scope="module")
def resource_file():
    def wrapper(*args) -> Path:
        return Path(__file__).parent.joinpath("resources", *args).resolve().absolute()

    return wrapper
