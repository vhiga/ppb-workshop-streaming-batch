class DataLakeDatabaseSubLayer:
    RAW = "raw"
    STAGE = "stage"
    ANALYTICS_BASE = "base"
    ANALYTICS_CURATED = "curated"


class BookmarkConstants:
    TABLE_SUFFIX = "tx"


class HudiConstants:
    HUDI_METADATA_COLUMNS = [
        "_hoodie_commit_time",
        "_hoodie_commit_seqno",
        "_hoodie_record_key",
        "_hoodie_partition_path",
        "_hoodie_file_name",
    ]
