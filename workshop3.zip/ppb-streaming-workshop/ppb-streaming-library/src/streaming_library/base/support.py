import logging


def init_logger(file_name, log_level=None):
    if not log_level:
        log_level = "INFO"

    logger = logging.getLogger(file_name)

    return logger
