import json
from abc import ABC, abstractmethod
from typing import Any, Dict

from awsglue import DynamicFrame
from awsglue.context import GlueContext
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.session import SparkSession
from streaming_library.base.support import init_logger
from streaming_library.common.catalog.entity import Entity
from streaming_library.common.stream.stream_utils import validate_schema


class StreamProcessor(ABC):
    """
    Stream Processor Interface. Concrete StreamProcessor should implement a parsing strategy.
    """

    def __init__(
        self,
        team_name: str,
        dataset: str,
        stream_arn: str,
        input_database_name: str,
        input_table_name: str,
        base_db_name: str = None,
        base_mdb_name: str = None,
        curated_db_name: str = None,
        curated_mdb_name: str = None,
        analytics_db_bucket_name: str = None,
        analytics_mdb_bucket_name: str = None,
        glue_job_connection_name: str = None,
        mask: bool = True,
        spark_session: SparkSession = None,
        glue_context: GlueContext = None,
        entities_expression: str = None,
        stream_read_repartition: int = 6,
        processing_df_repartition: int = None,
        log_level: str = "INFO",
    ) -> None:
        """
        Stream Definition
        """
        self.team_name = team_name
        self.dataset = dataset
        self.stream_arn = stream_arn
        self.mask = mask
        self.input_database_name = input_database_name
        self.input_table_name = input_table_name
        self.base_db_name = base_db_name
        self.base_mdb_name = base_mdb_name
        self.curated_db_name = curated_db_name
        self.curated_mdb_name = curated_mdb_name
        self.analytics_db_bucket_name = analytics_db_bucket_name
        self.analytics_mdb_bucket_name = analytics_mdb_bucket_name
        self.glue_job_connection_name = glue_job_connection_name
        self.spark_sesion = spark_session
        self.glue_context = glue_context
        self.entities_expression = entities_expression
        self.stream_read_repartition = stream_read_repartition
        self.processing_df_repartition = processing_df_repartition
        self.log_level = log_level
        self.logger = glue_context.get_logger()

    def start(
        self,
        glue_catalog_options: Dict[str, str],
        for_each_batch_options: Dict[str, str],
    ) -> None:
        self.logger.info("Starting Streaming Job")
        self.logger.info(str(glue_catalog_options))
        self.logger.info(str(for_each_batch_options))
        glue_data_source = self.glue_context.create_data_frame.from_catalog(
            database=self.input_database_name,
            table_name=self.input_table_name,
            transformation_ctx="DataSource0",
            additional_options=glue_catalog_options,
        )

        self.glue_context.forEachBatch(
            frame=glue_data_source,
            batch_function=self.process_batch,
            options=for_each_batch_options,
        )

    def process_batch(self, input_dataframe: SparkDataFrame, batch_id: int) -> None:
        input_count = input_dataframe.count()
        self.logger.info(f"Processing batch: {batch_id}, input df count: {input_count}")
        self.logger.info(f"The input dataframe is streaming: {input_dataframe.isStreaming}")
        self.logger.info(f"The input data frame is cached: {input_dataframe.is_cached}")

        self.logger.info("Input df schema: ")
        self.logger.info(str(input_dataframe.schema))

        if input_count > 0:
            parsed_entities = self.parse(input_dataframe=input_dataframe)

            for key in parsed_entities:
                entity = parsed_entities.get(key)
                if entity is not None:
                    entity_fqn = f"{entity.database_name}.{entity.table_name}"
                    self.logger.info(f"Processing entity: {entity.to_string()}")
                    kdf = DynamicFrame.fromDF(
                        dataframe=entity.dataframe,
                        glue_ctx=self.glue_context,
                        name=f"pddf_{entity.database_name}{entity.table_name}",
                    )

                    res = validate_schema(
                        self.glue_context,
                        self.spark_sesion,
                        kdf,
                        entity.database_name,
                        entity.table_name,
                    )

                    hwc = json.dumps(entity.hudi_write_configs, default=str)
                    row_count = entity.dataframe.count()
                    self.logger.info(f"{entity_fqn} row count: {row_count}")
                    self.logger.info(f"{entity_fqn} cached: {entity.dataframe.is_cached}")

                    if res:
                        self.glue_context.write_dynamic_frame.from_options(
                            frame=kdf,
                            connection_type="marketplace.spark",
                            connection_options=json.loads(hwc),
                        )
                        row_count = entity.dataframe.count()
                        self.logger.info(f"Successfully persisted {entity_fqn}")
                        self.logger.info(f"{entity_fqn} cached {entity.dataframe.is_cached}")
                        self.logger.info(f"{entity_fqn} row count (post-write): {row_count}")
                    else:
                        self.logger.error(f"Error validating schema for: {entity_fqn}")

                else:
                    self.logger.error(f"Parsed Entity {key} is None")

    @abstractmethod
    def parse(self, input_dataframe: SparkDataFrame) -> Dict[str, Entity]:
        pass

    def to_dict(self) -> Dict[str, Any]:
        res = {
            "team_name": self.team_name,
            "dataset": self.dataset,
            "stream_arn": self.stream_arn,
            "requires_masking": self.mask,
            "input_database_name": self.input_database_name,
            "input_table_name": self.input_table_name,
            "base_db_name": self.base_db_name,
            "base_mdb_name": self.base_mdb_name,
            "curated_db_name": self.curated_db_name,
            "curated_mdb_name": self.curated_mdb_name,
            "analytics_db_bucket_name": self.analytics_db_bucket_name,
            "analytics_mdb_bucket_name": self.analytics_mdb_bucket_name,
            "glue_job_connection_name": self.glue_job_connection_name,
        }
        return res

    def to_string(self) -> str:
        return str(self.to_dict())

    def __str__(self) -> str:
        return self.to_string()

    def __repr__(self) -> str:
        return self.to_string()
