# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
#
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services or both.
# -*- coding: utf-8 -*-
from pyspark.sql import SparkSession, DataFrame
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as ssf
from botocore.exceptions import ClientError
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import logging
import time
import os
import sys
import boto3
import json
import base64
import pytz
from datetime import datetime as dt
from typing import Dict

# Set logging
logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, os.getenv('LOG_LEVEL', 'INFO')))
logger.info('Start execution')

#Functions for updating status in DynamoDB conformance table
dyn_db = boto3.client("dynamodb")
ssm_client = boto3.client('ssm')
dynamodb_ingestion_table = ssm_client.get_parameter(Name='/SDLF/Dynamodb/Ingestion')['Parameter']['Value']
dynamodb_lastval_table = ssm_client.get_parameter(Name='/SDLF/Dynamodb/LastValue')['Parameter']['Value']

def get_parameter_from_parameter_store(parameter_name):

    response = ssm_client.get_parameter(
        Name=parameter_name,
        WithDecryption=True  
    )
    return response['Parameter']['Value']


# Format your date to a new one.
def formatDate(stringDate: datetime, initalFormat: str, expectedFormat: str) -> str:
    return datetime.strftime(datetime.strptime(stringDate.strftime(initalFormat), initalFormat), expectedFormat)


def send_sns_mail(topic_arn, msg, subject, sns=None):
    if not sns:
        sns = boto3.client('sns', endpoint_url="https://sns." + REGION + ".amazonaws.com")

    response = sns.publish(
        TopicArn = topic_arn,
        Message = msg,
        Subject = subject
    )

    logger.info(response)


# Get configuration params
def get_detail(s3_ingestion, table_name, dynamodb=None):
    response = {}
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb')
    
    table = dynamodb.Table('{}'.format(table_name))
    print('Table name {}'.format(table_name))
    try:
        response = table.get_item(Key={'s3_ingestion': s3_ingestion})
    except ClientError as e:
        logger.error(e.response['Error']['Message'])
    else:
        return response['Item'] if 'Item' in response else None

# Repartition the dataframe
def in_repartition(input_rdd, chunk_size, input_rdd_count):
    num_partitions = max(1, int(input_rdd_count / chunk_size))
    repartitioned_data = input_rdd.repartition(num_partitions)
    return repartitioned_data

## Function that obtains secret name
def get_secret_detail(secret_name):
    session = boto3.session.Session()
    region = session.region_name
    client = session.client(service_name='secretsmanager', region_name=region)
    secret = ""
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
        #logger.info(get_secret_value_response)
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        else:
            logger.error(e)
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = json.loads(get_secret_value_response['SecretString'])
        else:
            secret = json.loads(base64.b64decode(get_secret_value_response['SecretBinary']))
    return secret

# Writes a Spark Dataframe
def df_write_spark(df_in, partition, in_format, s3_path, schema_target, target_table):
    if len(partition) > 0:
        valpart = partition.split(',')

        if in_format == 'csv':
            write_df = df_in.write \
                .format(in_format) \
                .option("header",True) \
                .option("delimiter", "|") \
                .partitionBy(valpart) \
                .option("path", s3_path) \
                .mode("overwrite")

            write_df.save()
        else:
            write_df = df_in \
                .write \
                .partitionBy(valpart) \
                .format(in_format) \
                .option("path", s3_path) \
                .mode("overwrite")

            if len(schema_target) > 0 and len(target_table) > 0:
                write_df.saveAsTable('{}.{}'.format(schema_target, target_table))
            else:
                write_df.save()
    else:
        if in_format == 'csv':
            write_df = df_in \
                .write \
                .option("header", True) \
                .option("delimiter", "|") \
                .format(in_format) \
                .option("path", s3_path) \
                .mode("overwrite")

            write_df.save()
        else:
            write_df = df_in \
                .write \
                .format(in_format) \
                .option("path", s3_path) \
                .mode("overwrite")

            if len(schema_target) > 0 and len(target_table) > 0:
                write_df.saveAsTable('{}.{}'.format(schema_target, target_table))
            else:
                write_df.save()
    return df_in

# Formats date column for filter
def get_date_filter(filter, table_config, CHGHOUR):
    if 'date_column_type' in table_config:
        date_column_type = table_config.get('date_column_type')
    else:
        date_column_type = 'YYYYMMDD'

    date_column = table_config.get('date_column')
    begin_utc = datetime.now(timezone.utc) - timedelta(days=1)
    end_utc = datetime.now(timezone.utc)
    begin_utc_chg = begin_utc - timedelta(hours=int(CHGHOUR))
    end_utc_chg = end_utc - timedelta(hours=int(CHGHOUR))

    if "range_days" in table_config:
        IN_RANGE_DAYS = table_config['range_days']
        if len(IN_RANGE_DAYS) > 0:
            begin_utc = datetime.now(timezone.utc) - timedelta(days=int(IN_RANGE_DAYS))
            end_utc = datetime.now(timezone.utc)
            begin_utc_chg = begin_utc - timedelta(hours=int(CHGHOUR))
            end_utc_chg = end_utc - timedelta(hours=int(CHGHOUR))

    if "begin_date" in table_config and "end_date" in table_config:
        IN_BEGIN_DATE = table_config['begin_date']
        IN_END_DATE = table_config['end_date']

        if len(IN_BEGIN_DATE) == 10:
            IN_BEGIN_DATE = IN_BEGIN_DATE + ' 00:00'
        if len(IN_END_DATE) == 10:
            IN_END_DATE = IN_END_DATE + ' 00:00'

        begin_utc = datetime.strptime(IN_BEGIN_DATE, "%Y-%m-%d %H:%M")
        end_utc = datetime.strptime(IN_END_DATE, "%Y-%m-%d %H:%M")
        begin_utc_chg = pytz.utc.localize(begin_utc)
        end_utc_chg = pytz.utc.localize(end_utc)

    if date_column_type == 'DATETIMEOFFSET':
        filter = f"{filter} AND {date_column} >= '{formatDate(begin_utc_chg, '%Y-%m-%d %H:%M:%S.000', '%Y-%m-%d %H:%M:%S.000')}' " \
                 f" AND {date_column} <= '{formatDate(end_utc_chg, '%Y-%m-%d %H:%M:%S.000', '%Y-%m-%d %H:%M:%S.000')}' "
    elif date_column_type == 'smalldatetime':
        filter = f"{filter} AND {date_column} >= '{formatDate(begin_utc_chg, '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M:%S')}' " \
                 f" AND {date_column} <= '{formatDate(end_utc_chg, '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M:%S')}' "
    elif date_column_type == 'YYYYMMDD':
        filter = f"{filter} AND {date_column} >= '{formatDate(begin_utc_chg, '%Y-%m-%d', '%Y%m%d')}' " \
                 f" AND {date_column} <= '{formatDate(end_utc_chg, '%Y-%m-%d', '%Y%m%d')}' "

    return filter

#Creates configuration for Job
def read_config(table_config, con_params, CHGHOUR, OUT_S3, env):

    config_tables = []

    for table in table_config['tables']:
        select_clause = "*"
        if 'columns2project' in table:
            select_clause = table.get('columns2project')

        if 'load_type' in table:
            if (table.get('load_type').lower()) in ("full", ""):
                
                if 'query' in table:
                    SENTENCE = table['query']
                else:
                    if 'schema_ori' in table and len(table.get('schema_ori'))>0:
                        SENTENCE = "SELECT {} FROM {}.{}".format(select_clause, table.get('schema_ori'),
                                                         table.get('table_ori'))
                    else:
                        SENTENCE = "SELECT {} FROM {}".format(select_clause, table.get('table_ori'))
                    
                if 'filter' in table:
                    SENTENCE += " WHERE {}".format(table.get('filter'))
            else:
                # Use the filter
                filter = "(1=1)"
                if 'filter' in table:
                    if table.get('filter') != "":
                        filter = f"{filter} AND {table.get('filter')}"

                # Use date column
                if 'date_column' in table:
                    if table.get('date_column') != "":
                        filter = get_date_filter(filter, table, CHGHOUR)

                if 'incremental_column' in table:
                    if table.get('incremental_column') != "":
                        last_value = None
                        r_value = get_detail(OUT_S3, dynamodb_lastval_table)
                        if r_value:
                            last_value = r_value.get(
                                'incremental_column_last_value')
                        if last_value:
                            filter = f"{filter} AND {table.get('incremental_column')} > {last_value}"

                where_clause = f" {filter}"
                logging.info(f"where_clause: {where_clause}")

                if 'query' in table:
                    SENTENCE = table['query'] + " WHERE {}".format(where_clause)
                else:
                    if 'schema_ori' in table and len(table.get('schema_ori'))>0:
                        SENTENCE = "SELECT {} FROM {}.{}.{} WHERE {}".format(select_clause,table.get('dbname'), table.get('schema_ori'),
                                                                  table.get('table_ori'), where_clause)
                    else:
                        SENTENCE = "SELECT {} FROM {}.{} WHERE {}".format(select_clause,table.get('dbname'),table.get('table_ori'), where_clause)

        else:
            if 'query' in table:
                SENTENCE = table['query']
            else:
                SENTENCE = "SELECT {} FROM {}.{}.{}".format(
                    select_clause, table.get('dbname'), table.get('schema_ori'), table.get('table_ori'))
                
        connection_option = {
                "user": "{}".format(con_params['username']),
                "password": "{}".format(con_params['password'])
        }

        if 'addoption' in table:
            connection_option["dbtable"] = "( {} ) as temp_table".format(SENTENCE)
        else:
            connection_option["query"] = SENTENCE
            
        connection_option['url'] = "jdbc:mysql://{}:{}/{}".format(con_params['host'], con_params['port'], table.get('dbname'))
        connection_option['driver'] = "com.mysql.cj.jdbc.Driver"
        
        config_tables.append(connection_option)

    return config_tables

# Gets metrics of the ingested table
def get_metrics(df: DataFrame, tableConfig, query, CHGHOUR, count, OUT_S3):
    today_utc = datetime.now(timezone.utc)
    today_utc_chg = today_utc - timedelta(hours=int(CHGHOUR))
    data = {}
    data['exec_query'] = query
    data['date_exec'] = today_utc_chg.strftime("%Y-%m-%dT%H:%M:%S.000")
    data['s3_ingestion'] = OUT_S3
    data['conf_context'] = tableConfig
    incremental_column = tableConfig.get('incremental_column')

    if incremental_column is not None:
        data['incremental_column'] = incremental_column
        if df is not None:
            df_i_values = df.agg(ssf.max(incremental_column).alias('max_'), ssf.min(incremental_column).alias('min_'))
            values = df_i_values.collect()[0].asDict()
            data['incremental_column_last_value'] = values.get('max_')
            data['incremental_column_early_value'] = values.get('min_')

            if isinstance(values.get('max_'), float):
                data['incremental_column_last_value'] = Decimal(values.get('max_'))
            if isinstance(values.get('min_'), float):
                data['incremental_column_early_value'] = Decimal(values.get('min_'))

    data['rows_write_count'] = count

    return data

# Puts data in the DynamoDb table
def put_dynamo(tableName: str, data, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table(tableName)
    try:
        response = table.put_item(
            Item=data
        )
    except Exception as e:
        logging.error(f'Unable to put item in DynamoDB{e}')
    return


# Writes the metadata in the Dynamodb
def write_metadata(df: DataFrame, tableConfig, query, CHGHOUR, env, OUT_S3, count):
    data = get_metrics(df, tableConfig, query, CHGHOUR, count, OUT_S3)
    if df is not None and count > 0:
        put_dynamo('{}'.format(dynamodb_lastval_table), data)
    return

# Writes partition columns
def writes_partition(df: DataFrame, tableConfig, CHGHOUR):
    if df is not None:
        hours = 3600 * int(CHGHOUR)
        previtime = ssf.current_timestamp()
        if "end_date" in tableConfig:
            IN_END_DATE = tableConfig['end_date']
            if len(IN_END_DATE) == 10:
                IN_END_DATE = IN_END_DATE + ' 00:00'

            end_utc = datetime.strptime(IN_END_DATE, "%Y-%m-%d %H:%M")
            previtime = pytz.utc.localize(end_utc)

        if 'partition' in tableConfig:
            if tableConfig.get('partition') == "year,month,day":
                df_mod = df.withColumn('dt_tmp', ssf.to_timestamp(ssf.unix_timestamp(ssf.lit(previtime)) - hours))
                df_mod.createOrReplaceTempView("tmp")
                df_mod_1 = spark.sql(
                    "SELECT *, year(dt_tmp) as year, month(dt_tmp) as month, day(dt_tmp) as day FROM tmp")
                sqlDF = df_mod_1.drop('dt_tmp')
            elif tableConfig.get('partition') == "year,month,day,hour":
                df_mod = df.withColumn('dt_tmp', ssf.to_timestamp(ssf.unix_timestamp( ssf.lit(previtime)) - hours))
                df_mod.createOrReplaceTempView("tmp")
                df_mod_1 = spark.sql(
                    "SELECT *, year(dt_tmp) as year, month(dt_tmp) as month, day(dt_tmp) as day, day(dt_tmp) as hour FROM tmp")
                sqlDF = df_mod_1.drop('dt_tmp')
            elif tableConfig.get('partition') == tableConfig.get('date_column'):
                df_mod = df.withColumn('dt_tmp', df[tableConfig.get('date_column')].cast("string"))
                df_mod1 = df_mod.withColumn(tableConfig.get('date_column'), ssf.substring('dt_tmp', 0, 10))
                sqlDF = df_mod1.drop('dt_tmp')
            else:
                df.createOrReplaceTempView("tmp")
                sqlDF = spark.sql("SELECT *, current_date() as fch_audit FROM tmp")
        else:
            df.createOrReplaceTempView("tmp")
            sqlDF = spark.sql("SELECT *, current_date() as fch_audit FROM tmp")

        return sqlDF
    else:
        return df

#Validates time blocks in case that exist
def time_validation (item, thrshld, chghour):

    time_blocks = item.get('time_blocks')

    if time_blocks:
        for time in time_blocks:

            target_hour = time.split(":")
            c_time = dt.now() - timedelta(hours=int(chghour))
            target_time = dt(int(c_time.strftime("%Y")), int(c_time.strftime("%m")), int(c_time.strftime("%d")), int(target_hour[0]), int(target_hour[1]), 0)
            diff_min = ((target_time - c_time).total_seconds()) / 60
           
            if int(thrshld)*-1 <= diff_min <= int(thrshld):
                item['Active']='True'
                break
            else:
                item['Active']='False'
            
            logger.info(item)
                
    return item


# Resolve options
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'dict_config'])
logger.info("Dictionary config: {}".format(args['dict_config']))

# Set config
dict_entry = json.loads(args['dict_config'].replace("'", '"'))
out_s3 = dict_entry['exec']['s3_ingestion']
tbucket = dict_entry['bucket']
env = dict_entry['env']
CHGHOUR = dict_entry['chghour']

# Gets Job configuration
dict_param = get_detail(out_s3, dynamodb_ingestion_table)
sns_arn = dict_param['sns_arn']
REGION = dict_param['aws_region']
logger.info("Obtaining the configuration parameters")

for table in dict_param['tables']:
    # Check parameters
    if (not 'table_ori' in table) or (not 'schema_ori' in table) or (not 'schema_ori' in table):
        logger.error("Minimum input values not defined")
        sys.exit()
    if (not out_s3) or (not 'format_tgt' in table):
        logger.error("Minimum output values not defined")
        sys.exit()

## Set Spark context
sc = SparkContext()
glueContext = GlueContext(sc)
app_id = sc.applicationId 
#
if 'spark' not in globals():
    spark = SparkSession \
        .builder \
        .appName("ingest") \
        .config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2") \
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
        .config("spark.speculation", "false") \
        .config("hive.exec.dynamic.partition", "true") \
        .config("spark.rdd.compress", "true") \
        .config("hive.metastore.client.factory.class",
                "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory") \
        .config("spark.debug.maxToStringFields", "100") \
        .enableHiveSupport() \
        .getOrCreate()

job = Job(glueContext)
job.init(args['JOB_NAME'], args)

## Gets the detail of the secret
con_params = get_secret_detail(dict_param.get('secret'))
logger.info("Obtaining secret, detail for the connection")
#
## Creates the configuration for the Glue connection
connection_option = read_config(dict_param, con_params, CHGHOUR, out_s3, env)
logger.info("Creates connection and sentence to be executed")

#Attemps
attempts = int(dict_param['attempts'])
attempt_sleep = int(dict_param['attempt_sleep'])

error_tables = []
for table_config, table_detail in zip(connection_option, dict_param['tables']):

    attempt = 1
    
    table = time_validation (table_detail, CHGHOUR, CHGHOUR)
    
    while attempt <= attempts and table['Active'] == 'True':
        logger.info("Attempt " + str(attempt) + " for table: " + table['table_ori'])
        try:
            aproperties, addoption = {}, {}
            if 'fetchsize' in table:
                aproperties["fetchsize"] = table.get('fetchsize')
            if 'customSchema' in table:
                aproperties["customSchema"] = table.get('customSchema')
            if 'numPartitions' in table:
                aproperties["numPartitions"] = table.get('numPartitions')
            if 'addoption' in table:
                addoption = json.loads(table.get('addoption').replace("'", '"'))

            option = {**aproperties, **table_config, **addoption}
            
            ds_inputl = spark.read.format("jdbc").options(**option).load()
            logger.info("Executes the query in the source database")

            ## Checks the number of records
            count = 0
            if ds_inputl is not None:
                count = ds_inputl.count()
    
            if count > 0 and len(out_s3) > 0:

                if len(table['schema_ori'])>0:
                    if  table['dbname'] in out_s3 and not table['schema_ori'] in out_s3 and not table['table_ori'] in out_s3 :
                        raw_path = "s3://" + out_s3 + "/" + table['schema_ori'] + "/" + table['table_ori']
                    elif table['dbname'] in out_s3 and table['schema_ori'] in out_s3 and not table['table_ori'] in out_s3 :
                        raw_path = "s3://" + out_s3 + "/" + table['table_ori']
                    elif table['dbname'] in out_s3 and table['schema_ori'] in out_s3 and table['table_ori'] in out_s3 :
                        raw_path = "s3://" + out_s3
                    else:
                        raw_path = "s3://" + out_s3 + "/" + table['dbname'] + "/" + table['schema_ori'] + "/" + table['table_ori']
                else:
                    if  table['dbname'] in out_s3 and not table['table_ori'] in out_s3 :
                        raw_path = "s3://" + out_s3  + "/" + table['table_ori']
                    elif table['dbname'] in out_s3 and not table['table_ori'] in out_s3 :
                        raw_path = "s3://" + out_s3 + "/" + table['table_ori']
                    elif table['dbname'] in out_s3 and table['table_ori'] in out_s3 :
                        raw_path = "s3://" + out_s3
                    else:
                        raw_path = "s3://" + out_s3 + "/" + table['dbname'] + "/" + table['table_ori']
                
                logger.info(raw_path)
        
                # Writes partition columns
                ds_input_part = writes_partition(ds_inputl, table, CHGHOUR)
                logger.info("Creates the partition for the spark dataframe")
    
                # Repartitions the records by file
                if 'chnk_size' in table:
                    ds_input_rep = in_repartition(ds_input_part, int(table.get('chnk_size')), count)
                else:
                    ds_input_rep = ds_input_part
                logger.info("Repartition the spark dataframe")

                if 'repartition' in table and not 'chnk_size' in table:
                    ds_input_rep = ds_input_part.repartition(int(table.get('repartition')))
                else:
                    ds_input_rep = ds_input_part

                # Creates a target table
                if 'schema_tgt' in table and 'table_tgt' in table:
                    df_write_spark(ds_input_rep, table.get('partition'), table.get('format_tgt'), raw_path,
                        table.get('schema_tgt'), table.get('table_tgt'))
                else:
                    df_write_spark(ds_input_rep, table.get('partition'), table.get('format_tgt'), raw_path, "", "")
    
                logger.info("Writes the result into S3")

                # Writes metadata about process execution
                write_metadata(ds_inputl, table, option.get('query'), CHGHOUR, env, raw_path, count)
                logger.info("Writes the metadata into DynamoDB table")
                
            break
        except Exception as e:

            if 'Connection timed out' in str(e):
                raise Exception(str(e))

            time.sleep(attempt_sleep)
            logger.error("Error: " + str(e))
            
            msg = "The next tables had a problem at the extract process:\n"
            subject = "Error: Tables from origin " + dict_param['origin'] + " couln't be ingested"
            send_sns_mail(sns_arn, msg, subject)
            
            attempt += 1
            
            continue

job.commit()