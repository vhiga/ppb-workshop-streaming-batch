import sys

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.sql.session import SparkSession
from streaming_library.datasets.order.stream.order_tb_processor import (
    OrderReviewStreamProcessor,
)

args = getResolvedOptions(
    sys.argv,
    [
        "JOB_NAME",
        "TEAM_NAME",
        "DATASET",
        "STREAM_ARN",
        "INPUT_DB_NAME",
        "INPUT_TABLE_NAME",
        "KINESIS_ITERATOR_POSITION",
        "BASE_DB_NAME",
        "BASE_MDB_NAME",
        "CURATED_DB_NAME",
        "CURATED_MDB_NAME",
        "ANALYTICS_DB_BUCKET_NAME",
        "ANALYTICS_MDB_BUCKET_NAME",
        "GLUE_JOB_CONNECTION_NAME",
        "WINDOW_SIZE",
        "S3_SPARK_CHECKPOINT_PATH",
        "MAX_FETCH_TIME_IN_MS",
        "MAX_FETCH_RECORDS_PER_SHARD",
        "MAX_RECORD_PER_READ",
        "AVOID_EMPTY_BATCHES",
        "ENTITIES_EXPRESSION",
        "STREAM_READ_REPARTITION",
        "PROCESSING_DF_REPARTITION",
    ],
)


spark = (
    SparkSession.builder.config(
        "spark.serializer", "org.apache.spark.serializer.KryoSerializer"
    )
    .config("spark.sql.hive.convertMetastoreParquet", "false")
    .config("spark.driver.maxResultSize", "0")
    .config("spark.sql.parquet.compression.codec", "snappy")
    .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
    .config("hive.exec.dynamic.partition.mode", "nonstrict")
    # .config(
    #     "spark.sql.catalog.spark_catalog", "org.apache.spark.sql.hudi.catalog.HoodieCatalog"
    # )
    # .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension")
    .config("spark.sql.legacy.pathOptionBehavior.enabled", "true")
    .getOrCreate()
)

sc = spark.sparkContext
glue_context = GlueContext(sc)
log = glue_context.get_logger()
job = Job(glue_context)
job.init(args["JOB_NAME"], args)

team_name = args["TEAM_NAME"]
dataset = args["DATASET"]
stream_arn = args["STREAM_ARN"]
input_db_name = args["INPUT_DB_NAME"]
input_table_name = args["INPUT_TABLE_NAME"]
kinesis_iterator_pos = args["KINESIS_ITERATOR_POSITION"]
analytics_base_bd_name = args["BASE_DB_NAME"]
analytics_base_mbd_name = args["BASE_MDB_NAME"]
analytics_curated_bd_name = args["CURATED_DB_NAME"]
analytics_curated_mdb_name = args["CURATED_MDB_NAME"]
analytics_db_bucket_name = args["ANALYTICS_DB_BUCKET_NAME"]
analytics_mdb_bucket_name = args["ANALYTICS_MDB_BUCKET_NAME"]
glue_job_connection_name = args["GLUE_JOB_CONNECTION_NAME"]
window_size = args["WINDOW_SIZE"]
s3_spark_checkpoint_path = args["S3_SPARK_CHECKPOINT_PATH"]
max_fetch_time_in_ms = args["MAX_FETCH_TIME_IN_MS"]
max_fetch_records_per_shard = args["MAX_FETCH_RECORDS_PER_SHARD"]
max_record_per_read = args["MAX_RECORD_PER_READ"]
avoid_empty_batches = args["AVOID_EMPTY_BATCHES"]
entities_expression = args["ENTITIES_EXPRESSION"]
stream_read_repartition = int(args["STREAM_READ_REPARTITION"])
processing_df_repartition = int(args["PROCESSING_DF_REPARTITION"])

if processing_df_repartition == -1:
    processing_df_repartition = None

stream_processor = OrderReviewStreamProcessor(
    team_name=team_name,
    dataset=dataset,
    stream_arn=stream_arn,
    input_database_name=input_db_name,
    input_table_name=input_table_name,
    mask=False,
    base_db_name=analytics_base_bd_name,
    base_mdb_name=analytics_base_mbd_name,
    curated_db_name=analytics_curated_bd_name,
    curated_mdb_name=analytics_curated_mdb_name,
    analytics_db_bucket_name=analytics_db_bucket_name,
    analytics_mdb_bucket_name=analytics_mdb_bucket_name,
    glue_job_connection_name=glue_job_connection_name,
    spark_session=spark,
    glue_context=glue_context,
    entities_expression=entities_expression,
    stream_read_repartition=stream_read_repartition,
    processing_df_repartition=processing_df_repartition,
)


glue_catalog_options = {
    "inferSchema": "false",
    "emitConsumerLagMetrics": "true",
    "addRecordTimestamp": "true",
    "startingPosition": kinesis_iterator_pos,
    "maxFetchTimeInMs": max_fetch_time_in_ms,
    "maxFetchRecordsPerShard": max_fetch_records_per_shard,
    "maxRecordPerRead": max_record_per_read,
    "avoidEmptyBatches": avoid_empty_batches,
}

for_each_batch_options = {
    "windowSize": window_size,
    "checkpointLocation": s3_spark_checkpoint_path,
}

stream_processor.start(
    glue_catalog_options=glue_catalog_options,
    for_each_batch_options=for_each_batch_options,
)

job.commit()
