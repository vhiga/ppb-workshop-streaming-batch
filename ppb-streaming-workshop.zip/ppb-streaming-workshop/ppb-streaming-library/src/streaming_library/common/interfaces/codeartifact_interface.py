import os
from logging import Logger
from typing import Any, Optional
from urllib.parse import urlparse, urlunparse

import boto3
from botocore.exceptions import ClientError
from streaming_library.base.support import init_logger

from ..configuration.resource_configs import CodeArtifactConfiguration


class CodeArtifactPackageFormats:
    MAVEN = "maven"
    NPM = "npm"
    NUGET = "nuget"
    PYPI = "pypi"


class CodeArtifactInterface:
    _logger: Logger
    _client: Any
    _config: CodeArtifactConfiguration

    def __init__(
        self,
        config: CodeArtifactConfiguration,
        client: Optional[Any] = None,
        log_level: Optional[str] = None,
    ):
        self._logger = init_logger(__name__, log_level or os.getenv("LOG_LEVEL", "INFO"))
        self._client = client or boto3.client("codeartifact")
        self._config = config

    def get_authorization_token(self, duration: int) -> str:
        """
        Generates a temporary CodeArtifact authorization token
        for accessing repositories in the domain.

        Arguments
        ---------
        duration : int
            The time, in seconds, that the generated authorization token is valid.
            Valid values are `0` and any number between `900` (15 minutes) and `43200` (12 hours).
            A value of `0` will set the expiration of the authorization token to the same
            expiration of the user's role's temporary credentials.

        Returns
        -------
        str
            CodeArtifact authentication token.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            response = self._client.get_authorization_token(
                domain=self._config.domain_name,
                domainOwner=self._config.domain_owner,
                durationSeconds=duration,
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "AccessDeniedException":
                # You do not have sufficient access to perform this action.
                raise e
            elif e.response["Error"]["Code"] == "InternalServerException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "ValidationException":
                # The input fails to satisfy the constraints specified by an AWS service.
                raise e
            elif e.response["Error"]["Code"] == "ResourceNotFoundException":
                # We can"t find the resource that you asked for.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on get_authorization_token",
                    extra=error_botocore,
                )
                raise e

        return response["authorizationToken"]

    def get_repository_endpoint(self, format: str) -> str:
        """
        Returns the endpoint of a CodeArtifact repository for a specific package format.

        Arguments
        ---------
        format : str
            Which endpoint of a repository to return for the given package format.
            Valid values are `npm`, `pypi`, `maven`, and `nuget`.

        Returns
        -------
        str
            CodeArtifact endpoint URL for a specific package format.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            response = self._client.get_repository_endpoint(
                domain=self._config.domain_name,
                domainOwner=self._config.domain_owner,
                repository=self._config.repository_name,
                format=format,
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "AccessDeniedException":
                # You do not have sufficient access to perform this action.
                raise e
            elif e.response["Error"]["Code"] == "InternalServerException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "ValidationException":
                # The input fails to satisfy the constraints specified by an AWS service.
                raise e
            elif e.response["Error"]["Code"] == "ResourceNotFoundException":
                # We can"t find the resource that you asked for.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on get_repository_endpoint",
                    extra=error_botocore,
                )
                raise e

        return response["repositoryEndpoint"]

    def get_authenticated_pip_index_url(self, duration: int = 900) -> str:
        """
        Returns a Python package repository URL using basic HTTP authentication credentials.

        Arguments
        ---------
        duration : int
            The duration in seconds of the `CodeArtifact`
            authorization token. Defaults to `15` minutes.

        Returns
        -------
        str
            CodeArtifact endpoint URL representing a Python package repository.

        Notes
        -----
        rodopuig: a personal note on private method usage.

        See: [CodeSmell](https://martinfowler.com/bliki/CodeSmell.html)

        Source: [urllib.parse.urlparse]
        (https://docs.python.org/3.7/library/urllib.parse.html#urllib.parse.urlparse)

        “As is the case with all named tuples, the subclass has
        a few additional methods and attributes
        that are particularly useful. One such method is ``_replace()``.
        The ``_replace()`` method will
        return a new ParseResult object replacing specified fields with new values.”
        """
        # Fetch CodeArtifact resources
        repository_endpoint = self.get_repository_endpoint(
            format=CodeArtifactPackageFormats.PYPI
        )
        authentication_token = self.get_authorization_token(duration=duration)

        # Update CodeArtifact repository URL
        repository_endpoint_parsed = urlparse(repository_endpoint)
        repository_endpoint_netloc = (
            f"aws:{authentication_token}@{repository_endpoint_parsed.netloc}"
        )
        repository_endpoint_path = f"{repository_endpoint_parsed.path.strip('/')}/simple/"
        repository_endpoint_url = urlunparse(
            repository_endpoint_parsed._replace(
                netloc=repository_endpoint_netloc, path=repository_endpoint_path
            )
        )

        return repository_endpoint_url
