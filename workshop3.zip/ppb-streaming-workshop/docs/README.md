# AWS ProServe Partner Boost - Intelligence # 1

---

## Streaming Workshop

### Summary and High Level Architecture

Hands On Workshop where participants can learn how to leverage Kinesis Streams, Firehose, Glue Streaming, Apache Hudi and Code Artifact to build secure, scalable and robust stream processing applications. The workshop is designed for data engineering, data architecture and ML engineering roles.

![Solution Architecture](./images/architecture/architecture.png)

### Scope

- Deploy the infrastructure and security foundations of a Stream Processing Applications.
- Deploy the catalog and a Glue Streaming processing job.
- Publish a Streaming Application (Python Package) to CodeArtifact, that encapusulates the processing and business logic.
- Fine tune Hudi Configurations according to the context and streaming properties.

### Step by Step

1. Open the Cloud9 service via AWS Console. This is an integrated IDE in AWS Console. You can execute and follow the step by step using this service.

    - Create a new Cloud9 environment
    - Add your preferred name to the environment.
    - ***Adjust Timeout (select 7 days)***
    - Accept the other settings and their default values.
    - Click create.

        ![Open Cloud9 Service](./images/cloud9/cloud9-open.png)

        ![Create a Cloud9 instance](./images/cloud9/cloud9-create.png)

        ![Create a Cloud9 instance](./images/cloud9/cloud9-create2.png)

2. Download the source code of the workshop from a S3 Pre-Signed URL.

    ```sh
    curl '<PASTE PRESIGNED S3 URL HERE>' --output ppb-streaming-workshop-file.zip
    ```

3. Extract the source code to your workspace folder.

    ```sh
    unzip ppb-streaming-workshop-file.zip
    ```

4. Initialize the the Streaming Library Repository.

    ```sh
    git config --global user.name "Your Name"
    git config --global user.email youremail@example.com
    ```

    Move to the workshop home folder. This is your main workspace, all the commands should be run from this location if its not explicilty instructed otherwise.

    ```sh
    cd ppb-streaming-workshop
    ```

    ```sh
    cd ppb-streaming-library/ && git init --initial-branch=dev
    ```

    ```sh
    git remote add origin codecommit::us-east-1://ppb-streaming-library
    ```



5. Install the Streaming Library and other dependencies in your local Python environment.

    ```sh
    python3 -m pip install --editable .
    ```

    Install additional Python Packages required for the exercise.

    ```sh
    python3 -m pip install Faker boto3
    ```

    Verify that it was correctly installed.

    ```sh
    python3 -m pip list
    ```

    ![pip list](./images/cloud9/cloud9-pip-list.png)


6. Set Up Lake Formation and add TeamRole as Administrator

    Go to the Lake Formation Home Page and accept default settings (***Click get started***)

    ![LakeFormation get started](./images/lakeformation/lakeformation0.png)

    Verify you are a Lake Formation Administrator

    ![Add TeamRole as Lake Formation Admin](./images/lakeformation/lakeformation1.png)

    Edit Administration/Data Catalog Settings and uncheck ***Use only IAM access control for new databases*** and ***Use only IAM access control for new tables in new databases***. click save.

    ![Edit Catalog Settings](./images/lakeformation/lakeformation2.png)

7. Deploy Storage Stack

    This stack creates the infrastructure and security foundations for the Streaming Application. It creates the necessary IAM Roles, KMS Keys, Kinesis Streams, Firehose, S3 Buckets and more.

    Go to workshop home folder:

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/
    ```

    ```sh
    aws cloudformation deploy --stack-name ppbw-storage-security-stack --template-file ./cloudformation/storage/template.yaml --tags workshop=ppb-streaming --capabilities CAPABILITY_NAMED_IAM
    ```

8. Deploy Catalog and Processing Stack.

    This stack deploys a Glue Table for Kinesis Stream, a Glue Table for Analytics Workloads and a Glue Streaming job. Additionally it creates a simple CI/CD pipeline to upload a Python Package to AWS Code Artifact.

    Go to workshop home folder:

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/
    ```

    ```sh
    aws cloudformation deploy --stack-name ppbw-catalog-processing-stack --template-file ./cloudformation/analytics/template.yaml --tags workshop=ppb-streaming --capabilities CAPABILITY_NAMED_IAM
    ```

    ***Notes:***
    - ***Be sure that you have the AWS CLI credentials correctly configured***
    - ***Make sure that you are running the command from the correct location and pointing to the correct template file path.***

9. Upload the Glue Sripts.

    ```sh
    ACCOUNT_ID="$(aws sts get-caller-identity --query "Account" --output text)" && aws s3 cp ./support/glue/simplejob.py s3://ppb-us-east-1-$ACCOUNT_ID-artifacts/glue/scripts/simplejob.py && aws s3 cp ./support/glue/orderjob.py s3://ppb-us-east-1-$ACCOUNT_ID-artifacts/glue/scripts/orderjob.py
    ```

10. Upload PPB Streaming Library to CodeArtifact

    Move to the Streaming Library Repo

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/ppb-streaming-library
    ```

    Push the initial commit to the dev branch. This will trigger the CodeBuild logic that packages and publishes the Python Package to Code Artifact.

    ```sh
     git add . && git commit -m "Initial commit" && git push --set-upstream origin dev
    ```

11. Publish dummy records to Kinesis Streams.

    In the support folder you can execute a Python utility script that publishes dummy records to a specified Kinesis Stream. This is used only for workshops and demostrating purposes.

    ***Open a new Terminal in cloud9.***

    Move to the workshop home folder.

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/
    ```

    ```sh
    python3 support/kinesis/put_some_records.py -s ppb-simple-table-stream
    ```

12. Start the Glue Streaming Job to process a Simple Kinesis Table.

    In the support library you can execute a Python utility script that starts a Glue Streaming Job with the correct parameters. This Job will process and write the Kinesis Simple Table to the analytics layer. **Be sure that the code pipeline of streaming library finished successfully and uploaded to code to AWS code artifact**.

    Go back to the initial terminal.

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/
    ```

    ```sh
    python3 support/glue/start_glue_job.py -j ppb-glue-streaming-simple-table-job
    ```

    Review the Glue Jobs Logs for additional details, for example check **All Logs** and filter by ***GlueLogger***

13. Open an Athena Console and run some queries.

    ***Select ppb-athena-workgroup as your working group***. You can do this in the upper right corner of the Athena Query Editor home page.

    All the analytical data is stored in the Datasource: AwsDataCatalog and Database: ppb_analytics_db. Here are some ad-hoc queries:

    Sample query:

    ```sql
    SELECT * FROM "ppb_analytics_db"."tb_simple_table" LIMIT 10;
    ```

    View total records by country

    ```sql
    SELECT country, COUNT(*) as total 
    FROM "ppb_analytics_db"."tb_simple_table" 
    GROUP BY country ORDER BY total DESC LIMIT 10;
    ```

    View average latency by country

    ```sql
    SELECT country, avg(date_diff('second', "__src_timestamp", "dlk_processing_dttm")) as avg_latency
    FROM "ppb_analytics_db"."tb_simple_table" 
    GROUP BY country ORDER BY avg_latency DESC LIMIT 10;
    ```

14. For the order review table and stream, you can also find utility scripts.

    There is another Kinesis Stream called **ppb-order-review-table-stream**. The code processing logic can be found in this path **ppb-streaming-workshop/support/glue/order_tb_processor.py**. Add that code to the streaming library (replacing this file: **ppb-streaming-workshop/ppb-streaming-library/src/streaming_library/datasets/order/stream/order_tb_processor.py**). Commit the changes and push to the remote. This will update the AWS CodeArtifact Python Package. Now you can test the order review processing.

    Adding dummy records to the Kinesis Stream ppb-order-review-table-stream.

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/
    ```

    ```sh
    python3 support/kinesis/put_some_records.py -s ppb-order-review-table-stream
    ```

    Start the order review streaming job. **Be sure you have updated code artifact with the ltest changes.**

    ```sh
    cd /home/ec2-user/environment/ppb-streaming-workshop/
    ```

    ```sh
    python3 support/glue/start_glue_job.py -j ppb-glue-streaming-order-review-job
    ```

### Further reading and learning

- Review the Kinesis and Hudi CloudWatch Metrics.
- Review the Kinesis Firehose Deliver Alternatives
- Initialize a Spark UI server and analyze the Spark Streaming Application logs.

### Other references and material

- [AWS Streaming Whitepaper](https://d0.awsstatic.com/whitepapers/whitepaper-streaming-data-solutions-on-aws-with-amazon-kinesis.pdf "AWS Streaming Whitepaper")
- [Dive Deep in AWS Glue 4.0](https://aws.amazon.com/blogs/big-data/dive-deep-into-aws-glue-4-0-for-apache-spark/ "Dive Deep in Glue 4.0")
- [Glue Streaming Best Practices](https://aws.amazon.com/blogs/big-data/best-practices-to-optimize-cost-and-performance-for-aws-glue-streaming-etl-jobs/)
- [Build a serverless streaming pipeline using Glue and Apache Hudi](https://aws.amazon.com/blogs/big-data/build-a-serverless-pipeline-to-analyze-streaming-data-using-aws-glue-apache-hudi-and-amazon-s3/)
- [AWS CodeArtifact Introduction](https://docs.aws.amazon.com/whitepapers/latest/introduction-devops-aws/aws-codeartifact.html "Code Artifact Overview")
