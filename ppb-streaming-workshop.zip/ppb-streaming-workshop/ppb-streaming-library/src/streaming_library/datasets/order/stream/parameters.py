# Managed here for demo and workshop purposes. Its recommended
# that the Hudi parameters can be managed via a parameter store.

default_extrator = "org.apache.hudi.hive.MultiPartKeysValueExtractor"
default_payload_class = "org.apache.hudi.common.model.DefaultHoodieRecordPayload"


class SimpleTable:
    name = "tb_simple_table"
    primary_key = "table_pk"
    sort_key = "__src_timestamp"
    partitions_list = ["date_dt"]
    partitions_path = "date_dt"
    database = "ppb_analytics_db"


class OrderReviewTable:
    name = "tb_order_review"
    primary_key = "deliveryid"
    sort_key = "__src_timestamp"
    partitions_list = ["date_dt"]
    partitions_path = "date_dt"
    database = "ppb_analytics_db"


class ProcessingParameters:
    HUDI_CONFIGS = {
        "common_configs": {
            "className": "org.apache.hudi",
            "hoodie.metadata.enable": "false",
        },
        "cleaning_configs": {
            "hoodie.archive.automatic": "true",
            "hoodie.cleaner.commits.retained": 15,
            "hoodie.keep.max.commits": 30,
            "hoodie.keep.min.commits": 20,
            "hoodie.parquet.small.file.limit": 104857600,
        },
        "index_configs": {
            "hoodie.bloom.index.filter.type": "DYNAMIC_V0",
            "hoodie.bloom.index.use.caching": "true",
            "hoodie.index.type": "BLOOM",
        },
        "metric_configs": {
            "hoodie.metrics.on": "true",
            "hoodie.metrics.reporter.type": "CLOUDWATCH",
        },
        "storage_configs": {
            "hoodie.parquet.compression.codec": "snappy",
            "hoodie.parquet.dictionary.enabled": "true",
            "hoodie.parquet.max.file.size": 125829120,
        },
        "write_configs": {
            "hoodie.datasource.hive_sync.enable": "true",
            "hoodie.datasource.hive_sync.mode": "hms",
            "hoodie.datasource.hive_sync.partition_extractor_class": default_extrator,
            "hoodie.datasource.hive_sync.partition_fields": "",
            "hoodie.datasource.hive_sync.support_timestamp": "true",
            "hoodie.datasource.hive_sync.use_jdbc": "false",
            "hoodie.datasource.write.drop.partition.columns": "true",
            "hoodie.datasource.write.hive_style_partitioning": "true",
            "hoodie.datasource.write.operation": "upsert",
            "hoodie.datasource.write.payload.class": default_payload_class,
            "hoodie.datasource.write.precombine.field": "",
            "hoodie.datasource.write.reconcile.schema": "false",
            "hoodie.datasource.write.recordkey.field": "",
            "hoodie.datasource.write.row.writer.enable": "true",
            "hoodie.datasource.write.table.type": "COPY_ON_WRITE",
            "hoodie.upsert.shuffle.parallelism": 40,
        },
        "tb_simple_table": {
            "hoodie.table.name": SimpleTable.name,
            "path": "",
            "hoodie.datasource.hive_sync.table": SimpleTable.name,
            "hoodie.datasource.hive_sync.database": SimpleTable.database,
            "hoodie.datasource.write.partitionpath.field": SimpleTable.partitions_path,
            "hoodie.datasource.hive_sync.partition_fields": SimpleTable.partitions_path,
            "hoodie.datasource.write.precombine.field": SimpleTable.sort_key,
            "hoodie.datasource.write.recordkey.field": SimpleTable.primary_key,
            "hoodie.metrics.cloudwatch.namespace": "SimpleTableNamespace",
        },
        "tb_order_review": {
            "hoodie.table.name": OrderReviewTable.name,
            "path": "",
            "hoodie.datasource.hive_sync.table": OrderReviewTable.name,
            "hoodie.datasource.hive_sync.database": OrderReviewTable.database,
            "hoodie.datasource.write.partitionpath.field": OrderReviewTable.partitions_path,
            "hoodie.datasource.hive_sync.partition_fields": OrderReviewTable.partitions_path,
            "hoodie.datasource.write.precombine.field": OrderReviewTable.sort_key,
            "hoodie.datasource.write.recordkey.field": OrderReviewTable.primary_key,
            "hoodie.metrics.cloudwatch.namespace": "OrderReviewTableNamespace",
        },
    }
