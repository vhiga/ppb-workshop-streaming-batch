from __future__ import annotations

import os
from logging import Logger
from typing import Any, Dict, Optional

import boto3
from botocore.exceptions import ClientError
from streaming_library.base.support import init_logger

from ..configuration.resource_configs import CodeArtifactConfiguration
from ..interfaces.codeartifact_interface import CodeArtifactInterface


class GlueInterface:
    _logger: Logger
    _client: Any
    _codeartifact: Optional[CodeArtifactInterface]

    def __init__(
        self,
        codeartifact: Optional[CodeArtifactInterface] = None,
        client: Optional[Any] = None,
        log_level: Optional[str] = None,
    ) -> None:
        self._logger = init_logger(__name__, log_level or os.getenv("LOG_LEVEL", "INFO"))
        self._client = client or boto3.client("glue")
        self._codeartifact = codeartifact

    @staticmethod
    def register_team_modules(team_name: str) -> GlueInterface:
        """
        Returns a GlueInterface instance with CodeArtifact modules enabled.

        Arguments
        ---------
        team_name : str
            The name of Team who owns the CodeArtifact domain.

        Returns
        -------
        GlueInterface
            GlueInterface instance.
        """
        configuration = CodeArtifactConfiguration(team=team_name)
        codeartifact = CodeArtifactInterface(config=configuration)
        interface = GlueInterface(codeartifact=codeartifact)

        return interface

    def _update_job_arguments(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """
        Updates job arguments with global parameters.

        Arguments
        ---------
        args : dict
            The original job arguments.

        Returns
        -------
        dict
            Updated job arguments.
        """
        # Apply CodeArtifact repository endpoint when available
        if self._codeartifact is not None:
            codeartifact_url = self._codeartifact.get_authenticated_pip_index_url()
            args.update(
                {"--python-modules-installer-option": f"--index-url={codeartifact_url}"}
            )
        return args

    def start_job_run(
        self, JobName: str, Arguments: Dict[str, Any], **kwargs
    ) -> Dict[str, Any]:
        """
        Starts a job run using a job definition.

        Arguments
        ---------
        JobName : str
            Name of the job definition being run.
        Arguments : str
            The job arguments specifically for this run. They replace
            the default arguments set in the job definition itself.
        **kwargs : dict
            Other named arguments to pass to the StartJobRun API call.

        Returns
        -------
        string
            Glue job run ID.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            arguments = self._update_job_arguments(args=Arguments)
            response = self._client.start_job_run(
                JobName=JobName,
                Arguments=arguments,
                **kwargs,
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConcurrentRunsExceededException":
                # Too many jobs are being run concurrently.
                raise e
            elif e.response["Error"]["Code"] == "InternalServiceException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "EntityNotFoundException":
                # A specified entity does not exist.
                raise e
            elif e.response["Error"]["Code"] == "InvalidInputException":
                # The input provided was not valid.
                raise e
            elif e.response["Error"]["Code"] == "OperationTimeoutException":
                # The operation timed out.
                raise e
            elif e.response["Error"]["Code"] == "ResourceNumberLimitExceededException":
                # A resource numerical limit was exceeded.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on get_repository_endpoint",
                    extra=error_botocore,
                )
                raise e

        return response

    def start_job_run_for_pythonshell(
        self, JobName: str, Arguments: Dict[str, Any], **kwargs
    ) -> Dict[str, Any]:
        """
        Starts a job run using a job definition.

        Arguments
        ---------
        JobName : str
            Name of the job definition being run.
        Arguments : str
            The job arguments specifically for this run.
            They replace the default arguments set in the job definition itself.
        **kwargs : dict
            Other named arguments to pass to the StartJobRun API call.

        Returns
        -------
        string
            Glue job run ID.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            self._logger.info("Received Arguments {Arguments}")
            arguments = self._update_job_arguments(args=Arguments)
            ppm = "--additional-python-modules"
            pmio = "--python-modules-installer-option"
            arguments.update(
                {ppm: f"{arguments[ppm]} -i {arguments[pmio][12:len(arguments[pmio])]}"}
            )
            self._logger.info("Modified Arguments {Arguments}")
            response = self._client.start_job_run(
                JobName=JobName,
                Arguments=arguments,
                **kwargs,
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConcurrentRunsExceededException":
                # Too many jobs are being run concurrently.
                raise e
            elif e.response["Error"]["Code"] == "InternalServiceException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "EntityNotFoundException":
                # A specified entity does not exist.
                raise e
            elif e.response["Error"]["Code"] == "InvalidInputException":
                # The input provided was not valid.
                raise e
            elif e.response["Error"]["Code"] == "OperationTimeoutException":
                # The operation timed out.
                raise e
            elif e.response["Error"]["Code"] == "ResourceNumberLimitExceededException":
                # A resource numerical limit was exceeded.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on get_repository_endpoint",
                    extra=error_botocore,
                )
                raise e

        return response

    def get_job_run(self, JobName: str, RunId: str) -> Dict[str, Any]:
        """
        Retrieves the metadata for a given job run.

        Arguments
        ---------
        JobName : str
            Name of the job definition being run.
        RunId : str
            The ID of the job run.

        Returns
        -------
        dict
            Glue job run metadata.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            response = self._client.get_job_run(
                JobName=JobName,
                RunId=RunId,
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "InvalidInputException":
                # The input provided was not valid.
                raise e
            elif e.response["Error"]["Code"] == "InternalServiceException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "EntityNotFoundException":
                # A specified entity does not exist.
                raise e
            elif e.response["Error"]["Code"] == "OperationTimeoutException":
                # The operation timed out.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on get_job_run", extra=error_botocore
                )
                raise e

        return response

    def batch_stop_job_run(self, JobName: str, JobRunIds: list) -> Dict[str, Any]:
        """
        Stops one or more job runs for a specified job definition.

        Arguments
        ---------
        JobName : str
            Name of the job definition being run.
        RunId : list
            The IDs of the jobs to stop.

        Returns
        -------
        dict
            Glue jobs stop metadata.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            response = self._client.batch_stop_job_run(
                JobName=JobName,
                JobRunIds=JobRunIds,
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "InvalidInputException":
                # The input provided was not valid.
                raise e
            elif e.response["Error"]["Code"] == "InternalServiceException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "EntityNotFoundException":
                # A specified entity does not exist.
                raise e
            elif e.response["Error"]["Code"] == "OperationTimeoutException":
                # The operation timed out.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on batch_stop_job_run",
                    extra=error_botocore,
                )
                raise e

        return response

    def get_job_runs(self, JobName: str, MaxResults: int, NextToken: str) -> Dict[str, Any]:
        """
        Retrives metadata for all runs of a given job definition.

        Arguments
        ---------
        JobName : str
            Name of the job definition for which to retrieve all job runs.
        MaxResults : int
            The maximum size of the response.
        NextToken : str
            A continuation token, if this is acontinuation callhe jobs to stop.

        Returns
        -------
        dict
            Glue jobs stop metadata.

        Raises
        ------
        botocore.exceptions.ClientError
            [Boto3 Docs - Error handling]
            (https://boto3.amazonaws.com/v1/documentation/api/latest/guide/error-handling.html)
        """
        try:
            response = self._client.get_job_runs(
                JobName=JobName, MaxResults=MaxResults, NextToken=NextToken
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "InvalidInputException":
                # The input provided was not valid.
                raise e
            elif e.response["Error"]["Code"] == "InternalServiceException":
                # An error occurred on the server side.
                raise e
            elif e.response["Error"]["Code"] == "EntityNotFoundException":
                # A specified entity does not exist.
                raise e
            elif e.response["Error"]["Code"] == "OperationTimeoutException":
                # The operation timed out.
                raise e
            else:
                error_botocore = {
                    "BC_Error": e.response.get("Error").get("Code"),
                    "BC_Message": e.response.get("Error").get("Message"),
                    "BC_RetryAttempts": e.response.get("ResponseMetadata").get(
                        "RetryAttempts"
                    ),
                    "BC_HTTPStatusCode": e.response.get("ResponseMetadata").get(
                        "HTTPStatusCode"
                    ),
                    "BC_OperationName": e.response.get("operation_name"),
                }
                self._logger.error(
                    "Unexpected botocore.ClientError on batch_stop_job_run",
                    extra=error_botocore,
                )
                raise e

        return response
