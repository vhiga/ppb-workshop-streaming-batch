import itertools
from typing import Any, Dict, List, Union

import pyspark.sql.functions as F
from awsglue import DynamicFrame
from awsglue.context import GlueContext
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.functions import col
from pyspark.sql.session import SparkSession
from streaming_library.base.support import init_logger
from streaming_library.common.catalog.constants import HudiConstants
from streaming_library.common.catalog.entity import Entity

logger = init_logger(__name__)


def get_hudi_config(
    team_name: str,
    table_name: str,
    analytics_bucket: str,
    hudi_params: Dict[str, Union[str, int]],
) -> Dict[str, Union[str, int]]:
    path = f"s3://{analytics_bucket}/{team_name}/curated/{table_name}"

    hudi_params[table_name]["path"] = path

    config_list = [
        hudi_params["common_configs"],
        hudi_params["cleaning_configs"],
        hudi_params["index_configs"],
        hudi_params["metric_configs"],
        hudi_params["storage_configs"],
        hudi_params["write_configs"],
        hudi_params[table_name],
    ]

    combined_entity_hudi_configs = dict(
        itertools.chain(*(config.items() for config in config_list if config is not None))
    )

    return combined_entity_hudi_configs


def add_dlk_processing_dttm_to_dataframe(df: SparkDataFrame) -> SparkDataFrame:
    dlk_processing_dttm_colname = "dlk_processing_dttm"
    dlk_processing_dttm_function = F.current_timestamp()
    df = df.withColumn(dlk_processing_dttm_colname, dlk_processing_dttm_function)
    return df


def validate_schema(
    glue_context: GlueContext,
    spark_session: SparkSession,
    kinesis_df: DynamicFrame,
    database: str,
    table: str,
) -> bool:
    logger = glue_context.get_logger()
    glue_catalog_df = spark_session.sql(f"SELECT * FROM {database}.{table} LIMIT 0")
    columns_to_drop = HudiConstants.HUDI_METADATA_COLUMNS.copy()
    glue_catalog_df_sanitized = glue_catalog_df.drop(*columns_to_drop)
    target_schema = sanitized_dataframe_schema(glue_catalog_df_sanitized.schema.jsonValue())
    logger.info(f"Validating schema for {database} {table}")
    logger.info(f"Target Schema: {str(target_schema)}")

    kdf = kinesis_df.toDF()
    kdf = kdf.drop(*columns_to_drop)
    input_schema = sanitized_dataframe_schema(kdf.schema.jsonValue())

    logger.info(f"Input Schema: {str(input_schema)}")

    if input_schema == target_schema:
        logger.info("Success. Input Schema matches Target Schema")
    else:
        logger.error("Input schema doesn't match target schema")
        raise Exception("Exception! Input schema doesn't match target schema!")

    return True


def sanitized_dataframe_schema(schema_json_value: Dict[Any, Any]):
    sanitized_schema = {}

    for column in schema_json_value["fields"]:
        sanitized_schema[column["name"]] = column["type"]

    return sanitized_schema
