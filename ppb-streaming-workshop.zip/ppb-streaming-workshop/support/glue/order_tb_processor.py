from typing import Dict

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.functions import col
from pyspark.sql.types import DecimalType, IntegerType, StringType, TimestampType
from streaming_library.common.catalog.entity import Entity
from streaming_library.common.stream.processor import StreamProcessor
from streaming_library.common.stream.stream_utils import (
    add_dlk_processing_dttm_to_dataframe,
    get_hudi_config,
)
from streaming_library.datasets.order.stream.parameters import (
    OrderReviewTable,
    ProcessingParameters,
)


class OrderReviewStreamProcessor(StreamProcessor):
    def parse(self, input_dataframe: SparkDataFrame) -> Dict[str, Entity]:
        self.logger.info("Starting parse for Order Review stream processor")
        # parse (enrich, cascade, enforce data types, mask, remove extra columns)

        table_name = OrderReviewTable.name
        final_df = self.get_complex_table_dataframe(input_dataframe=input_dataframe)

        entity_hudi_configs = get_hudi_config(
            team_name=self.team_name,
            table_name=table_name,
            analytics_bucket=self.analytics_db_bucket_name,
            hudi_params=ProcessingParameters.HUDI_CONFIGS,
        )
        parsed_entity = Entity(
            table_name=table_name,
            database_name=self.curated_db_name,
            dataframe=final_df,
            hudi_write_configs=entity_hudi_configs,
        )

        result = {
            f"{table_name}:nonmasked": parsed_entity,
        }

        return result

    def get_complex_table_dataframe(self, input_dataframe: SparkDataFrame) -> SparkDataFrame:
        # extend
        df = add_dlk_processing_dttm_to_dataframe(input_dataframe)

        columns = [
            "deliveryid",
            "delivery.type as delivery_type",
            "order.amount as order_amount",
            "order.storeid as order_storeid",
            "order.tax as order_tax",
            "customer.id as customer_id",
            "customer.firstname as customer_firstname",
            "customer.lastname as customer_lastname",
            "customer.rating as customer_rating",
            "dlk_processing_dttm",
            "__src_timestamp",
            "date_dt",
        ]

        df = df.selectExpr(*columns)

        # enforce data types
        df = df.withColumn("deliveryid", col("deliveryid").cast(IntegerType()))
        df = df.withColumn("delivery_type", col("delivery_type").cast(StringType()))
        df = df.withColumn("order_amount", col("order_amount").cast(DecimalType(15, 2)))
        df = df.withColumn("order_storeid", col("order_storeid").cast(IntegerType()))
        df = df.withColumn("order_tax", col("order_tax").cast(DecimalType(15, 2)))
        df = df.withColumn("customer_id", col("customer_id").cast(IntegerType()))
        df = df.withColumn("customer_firstname", col("customer_firstname").cast(StringType()))
        df = df.withColumn("customer_lastname", col("customer_lastname").cast(StringType()))
        df = df.withColumn("customer_rating", col("customer_rating").cast(IntegerType()))
        df = df.withColumn("__src_timestamp", col("__src_timestamp").cast(TimestampType()))
        df = df.withColumn("date_dt", col("date_dt").cast(StringType()))

        return df
