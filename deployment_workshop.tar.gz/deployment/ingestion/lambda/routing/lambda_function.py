import os
import json
from datetime import datetime as dt, timedelta
import boto3
import logging
import re
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr

# Set logging
logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, os.getenv('LOG_LEVEL', 'INFO')))
logger.info('Inicia ejecucion')

region=os.environ['AWS_REGION']
ssm_client = boto3.client("ssm")
raw_bucket = ssm_client.get_parameter(Name='/SDLF/S3/RawBucket')['Parameter']['Value']
dynamodb_ingestion_table = ssm_client.get_parameter(Name='/SDLF/Dynamodb/Ingestion')['Parameter']['Value']
sm_ingestion_table_arn = ssm_client.get_parameter(Name='/SDLF/StateMachine/Ingestion')['Parameter']['Value']

def prepare_ingestion(item, list_out, complement, thrshld, chghour):

    base = { 
        "s3_ingestion": item.get('s3_ingestion'),
        "job": item.get('job'),
        "capacity": int(item.get('capacity'))
    }
    
    time_blocks = item.get('time_blocks')
    merge = {**complement, **base}
            
    if time_blocks:
        for time in time_blocks:
            target_hour = time.split(":")
            c_time = dt.now() - timedelta(hours=int(chghour))
            target_time = dt(int(c_time.strftime("%Y")), int(c_time.strftime("%m")), int(c_time.strftime("%d")), int(target_hour[0]), int(target_hour[1]), 0)
            diff_min = ((target_time - c_time).total_seconds()) / 60
            
            if int(thrshld)*-1 <= diff_min <= int(thrshld):
                list_out.append(merge)
    else:
        list_out.append(merge)  
    
    logger.info(list_out)


def get_detail_scan(dynamodb_table, dynamodb=None):
    try:
        if not dynamodb:
            dynamodb = boto3.resource('dynamodb',region_name= region)
        
        dbtable = dynamodb.Table(dynamodb_table)
        items = dbtable.scan(FilterExpression=Attr('Active').ne(False))
    except ClientError:
        msg = 'Error getting items from {} table'.format(dynamodb_table)
        logger.error(msg)    
        raise
    return items

#Function to start a step function state machine
def start_state_machine(sm_arn, input_data):
    stepfunctions_client = boto3.client('stepfunctions')
    response = stepfunctions_client.start_execution(
        stateMachineArn=sm_arn,
        input=json.dumps(input_data)
    )
    return response


def lambda_handler(event, context):
    """Checks if any items need processing and triggers state machine
    Arguments:
        event {dict} -- Dictionary with no relevant details
        context {dict} -- Dictionary with details on Lambda context 
    """

    # TODO Implement Redrive Logic (through message_group_id)
    try:

        logger.info('Fetching event data from previous step')
        logger.info(event)

        env = event['env']
        thrshld = event['thrshld']
        chghour = event['chghour']

        logger.info(raw_bucket)
        
        complement = { "capacity": 2 }
        
        ingestion_info = get_detail_scan(dynamodb_ingestion_table)
        
        list_out = []
        for item in ingestion_info.get('Items'):
            prepare_ingestion(item, list_out, complement, thrshld, chghour)
    
        if not list_out:
            return
        
        response = {
            'detail': {
                'ingest-date': str((dt.now() - timedelta(hours=int(chghour)))),
                "bucket": raw_bucket,
                "env": env,
                "chghour": chghour,
                "exec": list_out
            }
        }
         
        logger.info(response)
        logger.info('Starting State Machine Execution')
        start_state_machine(sm_ingestion_table_arn, response)
        
    except Exception as e:
        logger.error("Fatal error", exc_info=True)
        raise e
    return
