import argparse

from streaming_library.common.configuration.resource_configs import SSMConfiguration
from streaming_library.common.interfaces.glue_interface import GlueInterface
from streaming_library.common.interfaces.ssm_interface import SSMInterface


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-j", "--job", required=True, help="Job Name")
    args = vars(ap.parse_args())
    job_name = args["job"]

    configuration = SSMConfiguration()
    ssm_interface = SSMInterface(configuration)
    artifacts_bucket = ssm_interface.get_ssm_parameter("/S3/rArtifactsBucket")
    stream_arn = None
    input_table_name = None

    if job_name == "ppb-glue-streaming-order-review-job":
        input_table_name = "tb_streaming_order_review_table"
        stream_arn = ssm_interface.get_ssm_parameter(key="/Kinesis/Streams/OrderReviewTable")
    elif job_name == "ppb-glue-streaming-simple-table-job":
        input_table_name = "tb_streaming_simple_table"
        stream_arn = ssm_interface.get_ssm_parameter(key="/Kinesis/Streams/SimpleTable")
    else:
        raise Exception("Job doesn't exist")

    team_name = "ppb"
    dataset = "NOT NEEDED"
    input_db_name = "ppb_kinesis_db"
    s3_checkpoint_path = f"s3://{artifacts_bucket}/{team_name}/sparkcheckpoint/{job_name}/"

    base_db_name = "NOT NEEDED"
    base_mdb_name = "NOT NEEDED"
    curated_db_name = "ppb_analytics_db"
    curated_mdb_name = "NOT NEEDED"
    analytics_db_bucket_name = ssm_interface.get_ssm_parameter("/S3/rAnalyticsBucket")
    analytics_mdb_bucket_name = "NOT NEEDED"
    glue_job_connection_name = "NOT NEEDED"

    client = GlueInterface.register_team_modules(team_name="ppb")

    print(f"Starting Job: {job_name}")
    job_response = client.start_job_run(
        JobName=job_name,
        Arguments={
            # Specify any arguments needed based on bucket and keys (e.g. input/output S3 locations)
            "--enable-continuous-cloudwatch-log": "true",
            "--job-bookmark-option": "job-bookmark-disable",
            "--enable-continuous-log-filter": "true",
            "--enable-metrics": "true",
            "--enable-glue-datacatalog": "true",
            "--additional-python-modules": "streaming-library",
            "--JOB_NAME": job_name,
            "--datalake-formats": "hudi",
            "--TEAM_NAME": team_name,
            "--DATASET": dataset,
            "--STREAM_ARN": stream_arn,
            "--STREAM_NAME": stream_arn,
            "--INPUT_DB_NAME": input_db_name,
            "--INPUT_TABLE_NAME": input_table_name,
            "--KINESIS_ITERATOR_POSITION": "LATEST",
            "--BASE_DB_NAME": base_db_name,
            "--BASE_MDB_NAME": base_mdb_name,
            "--CURATED_DB_NAME": curated_db_name,
            "--CURATED_MDB_NAME": curated_mdb_name,
            "--ANALYTICS_DB_BUCKET_NAME": analytics_db_bucket_name,
            "--ANALYTICS_MDB_BUCKET_NAME": analytics_mdb_bucket_name,
            "--GLUE_JOB_CONNECTION_NAME": "NOT NEEDED",
            "--WINDOW_SIZE": "10 seconds",
            "--S3_SPARK_CHECKPOINT_PATH": s3_checkpoint_path,
            "--MAX_FETCH_TIME_IN_MS": "2000",
            "--MAX_FETCH_RECORDS_PER_SHARD": "100000",
            "--MAX_RECORD_PER_READ": "10000",
            "--AVOID_EMPTY_BATCHES": "True",
            "--ENTITIES_EXPRESSION": "none",
            "--STREAM_READ_REPARTITION": "4",
            "--PROCESSING_DF_REPARTITION": "4",
        },
    )

    print(job_response)


if __name__ == "__main__":
    main()
