import json
import logging
import os
import uuid
from datetime import datetime
import urllib.parse
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from urllib.parse import unquote_plus

# Set logging
logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, os.getenv('LOG_LEVEL', 'INFO')))
logger.info('Inicia ejecucion')

s3 = boto3.client('s3')
ssm_client = boto3.client("ssm")
sm_merge_table_arn = ssm_client.get_parameter(Name='/SDLF/StateMachine/Merge')['Parameter']['Value']

def parse_s3_event(s3_event):
    return {
        "bucket": unquote_plus(s3_event['Records'][0]['s3']['bucket']['name']),
        "key": unquote_plus(s3_event['Records'][0]["s3"]["object"]["key"]),
        "size": s3_event['Records'][0]["s3"]["object"]["size"],
        "last_modified_date": s3_event['Records'][0]["eventTime"].split(".")[0] + "+00:00",
        "timestamp": int(round(datetime.utcnow().timestamp() * 1000, 0))
    }

#Function to start a step function state machine
def start_state_machine(sm_arn, input_data):
    stepfunctions_client = boto3.client('stepfunctions')
    response = stepfunctions_client.start_execution(
        stateMachineArn=sm_arn,
        input=json.dumps(input_data)
    )
    return response

def lambda_handler(event, context):
    logger.info("Received event: " + json.dumps(event, indent=2))

    for record in event["Records"]:
        logger.info("Parsing S3 Event")
        message = parse_s3_event(json.loads(record["body"]))
        
        logger.info("Formated message: {}".format(message))
        key = message.get('key')
        if not '._temporary.' in key and not 'spark-staging' in key and not '$folder$' in key:
            logger.info('Call step functions')
            start_state_machine(sm_merge_table_arn, message)
    return        





































































































































































































































































































































































