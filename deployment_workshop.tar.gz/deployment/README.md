# AWS ProServe Partner Boost - Intelligence 

---

## Ingesting Relational Database Data with AWS Glue Workshop

### Summary and High Level Architecture

Whether you recently started your journey with AWS analytics or already have experience, in this workshop you will see how to integrate information from relational databases using batch ingestion pattern. Also, since data can contain new or updated records coming from the source systems, you will see how to do the merge using Apache Hudi. The architecture that we will review, would be composed from two data pipelines, the first one to do the ingestion and the second one for the merge.


![Solution Architecture](./images/architecture/architecture.png)


### Scope

- Deploy the database infrastructure and network configuration from which we will get the information.
- Deploy a cloud9 instance and configure the libraries/dependencies that are need it.
- Deploy the ingestion data pipeline and create the configuration.
- Deploy the merge data pipeline and create the configuration.
- Execute the end-to-end processes, with some queries.


### Step by Step

1. Make sure that you are in the correct AWS region

    For this workshop we are going to use US West (Oregon) / us-west-2 

2. Set up a cloud9 environment
    
    Create a new cloud9 environment 
    
    Specify a name for your environment in this case we are using "dev_env", we are going to select the type as "New EC2 instance"

    We are going to leave the default values for the instance type (t2.micro), platform and timeout
    
    For networking we are going to use default values and we will click in "Create" button
    
    We will see the new environment being created, we will click in the "Open" button
 
3. Download the source code of the workshop from a S3 Pre-Signed URL. 
 
    ```sh
        curl -X GET "<PASTE PRESIGNED S3 URL HERE>" -o "deployment_workshop.tar.gz"
        tar -xvzf deployment_workshop.tar.gz
    ```   

4. Configure the AWS client and dependent libraries
 
    In the new cloud9 environment we are going to execute the following commands in the terminal

    ```sh
        curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
        unzip awscliv2.zip
        sudo ./aws/install
        sudo ./aws/install --bin-dir /usr/local/bin --install-dir /usr/local/aws-cli --update
        aws --version
        sudo yum install jq -y
    ```

    close the Cloud9 terminal and open a new one, in the same environment.

4. Deploy Foundation Stack

    This stack creates the infrastructure and security foundations, for the pipelines that we are going to deploy. It has the basic resources like the S3 buckets, RDS MySQL DB, SSM parameters and secret for the connection. It takes around 5-10 minutes to deploy.

    ```sh
        cd /home/ec2-user/environment/
        aws cloudformation deploy --stack-name foundation-base-stack --template-file ./deployment/base/db_ori_config.yaml --tags workshop=wksp-batch --capabilities CAPABILITY_NAMED_IAM
    ```
    We can check the status of the stack in the CloudFormation service, under the name "foundation-base-stack".

5. Deploy ingestion pipeline

    This stack deploys IAM roles, Glue job, DynamoDB configuration tables, routing lambda and Step function workflow. It also creates and event in Eventbridge service, saving some parameters for the execution. It takes around 2 minutes to deploy.
    
    ```sh
        cd /home/ec2-user/environment/deployment/ingestion
        sh deploy.sh
    ```

    ***Notes:***
    - *** Make sure that you are running the command from the correct location and pointing to the correct template file path.***
    - *** If you are curious about the deploy.sh script, you can execute a "sh deploy.sh -h" and see the input options.***
    - *** To review the creation events, you can go to the CloudFormation service and check the " sdlf-ingestion" stack. ***

6. Configure ingestion pipeline and execute

    To execute the ingestion pipeline, we first need to configure the process in the octagon-ingestion table, so we are going to update the "mysql.json" file that has the basic parameters for the execution.
     
     ```sh
        cd /home/ec2-user/environment/deployment/dynamodb_config/ingestion
    ```
    We are going to update the AWS ACCOUNT number in the "s3_ingestion" and "sns_arn" parameters, replacing the AWS_ACCOUNT parameter with your respective AWS account. Using the following commands:
    
    ```sh
        ACCOUNT_ID="$(aws sts get-caller-identity --query "Account" --output text)" && sed "s/<AWS_ACCOUNT>/$ACCOUNT_ID/g" mysql.json > /home/ec2-user/environment/deployment/ingestion/output/mysql_a.json
        cd /home/ec2-user/environment/deployment/ingestion/output
        aws dynamodb put-item --table-name octagon-ingestion --item file://mysql_a.json --return-consumed-capacity TOTAL
    ```
    
    To execute the pipeline, the CloudFormation stack creates an event rule (sdlf-ingestion-trigger) in the Eventbridge service that calls a lambda to execute the process, in this case we are going to call the lambda "sdlf-ingesta-routing" directly, with the following command that uses a test JSON example.
    
    ```sh    
        aws lambda invoke --function-name sdlf-ingesta-routing  --cli-binary-format raw-in-base64-out --payload '{ "env": "dev", "thrshld": "6", "chghour": "6" }' response.json
    ```
    
    Then we can go to the Step function state machine "sdlf-ingestion-pipeline" and we will see running our workflow, we can also validate the Glue job "sdlf-mysqlspark-glue-job" execution.
    
    The results will be written in the bucket "s3://dlk-wksp-us-west-2-AWS_ACCOUNT-raw/mysql/sampledb/", to verify the content we will execute the following command:
    
    ```sh    
        ACCOUNT_ID="$(aws sts get-caller-identity --query "Account" --output text)" && aws s3 ls s3://dlk-wksp-us-west-2-$ACCOUNT_ID-raw/mysql/sampledb/
    ```    
    you should see two tables "product" and "store".

    
7. Deploy merge pipeline

    This stack deploys IAM roles, Glue job, DynamoDB configuration table, event source mapping, routing merge lambda and step function workflow. It also creates some parameters from SSM for the execution. It takes around 2 minutes to deploy.

    ```sh
        cd /home/ec2-user/environment/deployment/merge
        sh deploy.sh
    ```

    ***Notes:***
    - *** Make sure that you are running the command from the correct location and pointing to the correct template file path.***
    - *** If you are courios about the deploy.sh script, you can execute a "sh deploy.sh -h" and see the input options .***
    - *** To review the creation events you can go to the CloudFormation service and check the "sdlf-merge" stack. ***


8. Configure merge pipeline and execute

     To execute the merge pipeline, we first need to configure the processes in the octagon-merge table, with the following commands:
    
    ```sh
        cd /home/ec2-user/environment/deployment/dynamodb_config/merge
        aws dynamodb put-item --table-name octagon-merge --item file://product.json --return-consumed-capacity TOTAL
        aws dynamodb put-item --table-name octagon-merge --item file://store.json --return-consumed-capacity TOTAL
    ```

    To execute the merge pipeline, we have two options we can copy the files that we have in the raw layer to trigger a S3 event or we can re execute the ingestion pipeline to obtain new, we are going to do the first one using the command:

    ```sh
        ACCOUNT_ID="$(aws sts get-caller-identity --query "Account" --output text)" && aws s3 cp s3://dlk-wksp-us-west-2-$ACCOUNT_ID-raw/mysql/ s3://dlk-wksp-us-west-2-$ACCOUNT_ID-raw/mysql/ --recursive
    ```
    
    With the previous you will see that the merge pipeline (sdlf-merge-pipeline) will start in the Step Function state machine.
    
9. Query tables using Athena
 
    With the creation of the tables using the merge pipeline, we can execute queries over the content. Select “wksp-athena-workgroup” as your working group. You can do this in the upper right corner of the Athena Query Editor home page.
    Tables will be stored in the Datasource: AwsDataCatalog and Database: stage_wksp_sampledb. Here an example query:

    ```sh
         SELECT dept, category, sum(price) as price FROM "stage_wksp_sampledb"."product" 
        group by dept, category
    ```    

10. Additional activities

    For homework, you can do a full and incremental ingestion for the table “productorder”, also you will configure the advanced configuration for Spark JDBC in the ingestion configuration table. For the merge, you will create the configuration for the same table. When you finish that you will execute an end-to-end test.


### Further reading and learning

- https://catalog.us-east-1.prod.workshops.aws/workshops/42a19ab2-99a2-4255-a129-129a336fcef5/en-US
- https://aws.amazon.com/blogs/big-data/part-1-build-your-apache-hudi-data-lake-on-aws-using-amazon-emr/
- https://catalog.us-east-1.prod.workshops.aws/workshops/520e974c-0fee-4585-9601-9af535d4d908/en-US
- https://aws.amazon.com/blogs/big-data/loading-ongoing-data-lake-changes-with-aws-dms-and-aws-glue/
- https://aws.amazon.com/blogs/big-data/use-sqoop-to-transfer-data-from-amazon-emr-to-amazon-rds/
- https://aws.amazon.com/blogs/big-data/land-data-from-databases-to-a-data-lake-at-scale-using-aws-glue-blueprints/
- https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-format-hudi.html
