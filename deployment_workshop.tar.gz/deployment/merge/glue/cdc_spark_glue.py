# -*- coding: utf-8 -*-
#
# Copyright 2018 Amazon.com, Inc. and its affiliates. All Rights Reserved.
#
# Licensed under the Amazon Software License (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
#   http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.
#

import sys
import json
import os
import logging
import boto3
from botocore.exceptions import ClientError

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import concat, col, expr, lit, to_timestamp, md5, current_timestamp
from pyspark.sql.functions import col, row_number, udf
from pyspark.sql.window import Window

from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'dict_config', 's3_target'])

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
job = Job(glueContext)

# Establece el logeo
logging.basicConfig()
logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, os.getenv('LOG_LEVEL', 'INFO')))
logger.info('Inicia ejecucion')
logger.info("El dict de configuracion es: {}".format(args['dict_config']))
logger.info("El S3 path de target: {}".format(args['s3_target']))

# Get configuration params
def get_detail(object_key, table_name, dynamodb=None):
    response = {}
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('{}'.format(table_name))
    print('Table name {}'.format(table_name))
    try:
        response = table.get_item(Key={'object_key': object_key})
    except ClientError as e:
        logger.error(e.response['Error']['Message'])
    else:
        return response['Item'] if 'Item' in response else None

def run_cdc(s3_inputp, s3_targetp, item):
    
    logger.info(item)
    logger.info(s3_targetp)
    logger.info(s3_inputp)
    
    s3_input = s3_inputp
    s3_target = s3_targetp
    sch_target = item["sch_target"]
    target_tbl = item["target_tbl"]
    cdc_type = item["cdc_type"]
    delimiter = item["delimiter"]
    
    
    if 'typeload' in item:
        typeload = "update" if item["typeload"] != "initial" or item["typeload"] == "" else "initial"
    else:
        typeload = "update"

    if cdc_type == "hudi":
        dt_comb = item["dt_comb"]
        part_colum = item["partition_columns"]
        key_colums = item["key_columns"]
        partition = 10 if len(item["partition"])<=0 else item["partition"]
    elif cdc_type == "otro":
        key_colums = item["key_columns"]
        part_colum = item["partition_columns"]
    else:
        part_colum = item["partition_columns"]

    dest_path = s3_target + '/' + sch_target + '/' + target_tbl
    dest_tab = sch_target + '.' + target_tbl

    if cdc_type == "hudi":
        logger.info("CDC hudi")

        spark = SparkSession.builder. \
            appName("Spark_CDC_"). \
            config("spark.worker.cleanup.enabled", "true"). \
            config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2"). \
            config("spark.speculation", "false").config("hive.exec.dynamic.partition", "true"). \
            config("hive.exec.dynamic.partition.mode", "nonstrict"). \
            config("spark.sql.hive.convertMetastoreParquet", "false"). \
            config("spark.serializer", "org.apache.spark.serializer.KryoSerializer"). \
            config("spark.rdd.compress", "true"). \
            config("spark.debug.maxToStringFields", "256"). \
            config("spark.sql.parquet.cacheMetadata", "false"). \
            enableHiveSupport().getOrCreate()

        commonConfig= {
            'hoodie.table.name': target_tbl,
            'hoodie.datasource.write.recordkey.field': "id_md5",
            'hoodie.datasource.write.precombine.field': dt_comb,
            'hoodie.datasource.write.table.name': target_tbl,
            'hoodie.datasource.hive_sync.database': sch_target,
            'hoodie.datasource.hive_sync.table': target_tbl,
            'hoodie.datasource.hive_sync.enable' :  True,
            'hoodie.datasource.meta.sync.enable': True,
            "hoodie.datasource.write.storage.type": "COPY_ON_WRITE",
            'hoodie.datasource.hive_sync.use_jdbc' :  False
        }     

        incrementalConfig = {
            'hoodie.upsert.shuffle.parallelism': partition,
            'hoodie.datasource.write.operation': 'upsert',
            'hoodie.cleaner.policy': 'KEEP_LATEST_COMMITS',
            'hoodie.cleaner.commits.retained': 5
        }


        unpartitionDataConfig = {
            'hoodie.datasource.hive_sync.partition_extractor_class': 'org.apache.hudi.hive.NonPartitionedExtractor',
            'hoodie.datasource.write.keygenerator.class': 'org.apache.hudi.keygen.NonpartitionedKeyGenerator'
        }

        partitionDataConfig = {
            'hoodie.datasource.write.partitionpath.field': part_colum,
            'hoodie.table.keygenerator.class' : 'org.apache.hudi.keygen.ComplexKeyGenerator',
            'hoodie.datasource.write.keygenerator.class': 'org.apache.hudi.keygen.ComplexKeyGenerator',
            'hoodie.datasource.hive_sync.partition_fields': part_colum
        }

        initLoadConfig = {
            'hoodie.bulkinsert.shuffle.parallelism': partition,
            'hoodie.datasource.write.operation': 'bulkinsert'
        }
        

        df_input = spark.read.option("inferschema", "true").option("delimiter", delimiter).option("header", "true").csv(s3_input)
        df_delta = df_input.withColumn("id_md5",
                                       md5(concat(*(col(c).cast("string") for c in key_colums.split(","))))).withColumn(
            "fch_audit", current_timestamp())

        if 'initial' in typeload:
            if len(part_colum) != 0 :
                logger.info("Initial load with partitions")
                combinedConf = {**commonConfig, **partitionDataConfig, **initLoadConfig}
                logger.info(combinedConf)
                df_delta.write.format('org.apache.hudi').options(**combinedConf).mode('Overwrite').save(dest_path)
            else:
                logger.info("Initial load without partitions")
                combinedConf = {**commonConfig, **unpartitionDataConfig, **initLoadConfig}
                logger.info(combinedConf)
                df_delta.write.format('org.apache.hudi').options(**combinedConf).mode('Overwrite').save(dest_path)
        else:
            if len(part_colum) != 0 :
                print("Upsert with partitions")
                combinedConf = {**commonConfig, **partitionDataConfig, **incrementalConfig}
                logger.info(combinedConf)
                df_delta.write.format('org.apache.hudi').options(**combinedConf).mode('Append').save(dest_path)
            else:
                logger.info("Upsert without partitions")
                combinedConf = {**commonConfig, **unpartitionDataConfig, **incrementalConfig}
                logger.info(combinedConf)
                df_delta.write.format('org.apache.hudi').options(**combinedConf).mode('Append').save(dest_path)
        spark.stop()
        logger.info("Hudi process finished")
        
    elif cdc_type == "otro":
        logger.info("CDC other")

        spark = SparkSession \
            .builder \
            .appName("Full") \
            .config("hive.metastore.client.factory.class",
                    "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory") \
            .config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2") \
            .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
            .config("hive.exec.dynamic.partition", "true") \
            .enableHiveSupport() \
            .getOrCreate()

        df_input = spark.read.option("inferschema", "true").option("delimiter", delimiter).option("header", "true").csv(s3_input)
        df_delta = df_input.withColumn("id_md5",
                                       md5(concat(*(col(c).cast("string") for c in key_colums.split(","))))).withColumn(
            "fch_audit", current_timestamp())

        schema = df_delta.schema

        try:
            existingData = spark.read.parquet(dest_path)
        except Exception as e:
            logger.info("Destination path doesn't exist")
            existingData = sc.parallelize([]).toDF(schema)

        df_ent = existingData.unionByName(df_delta)
        df_entlt = df_ent.withColumn("row_num",
                                     row_number().over(Window.partitionBy("id_md5").orderBy(col("fch_audit").desc())))
        df_entltf = df_entlt.filter(df_entlt.row_num == 1).drop(df_entlt.row_num)

        try:
            df_entltf.coalesce(5).write.format("parquet").option("compression", "snappy").option("path",
                                                                                                 dest_path + "_tmp").mode(
                "overwrite").save()
            df_entltf_tmp = spark.read.parquet(dest_path + "_tmp")
        except Exception as e:
            logger.error("Failure when we write in temporal")

        df_final = df_entltf_tmp.write \
            .format("parquet") \
            .option("compression", "snappy") \
            .option("path", dest_path) \
            .mode("overwrite")

        if len(part_colum) > 0:
            df_final.partitionBy(part_colum)

        if len(target_tbl) > 0 and len(sch_target) > 0:
            df_final.saveAsTable('{}'.format(dest_tab))
        else:
            df_final.save()

        spark.stop()
        logger.info("Other process finished")
    else:
        logger.info("CDC type not defined")
        spark = SparkSession \
            .builder \
            .appName("Full") \
            .config("hive.metastore.client.factory.class",
                    "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory") \
            .config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2") \
            .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
            .config("hive.exec.dynamic.partition", "true") \
            .enableHiveSupport() \
            .getOrCreate()

        df_input = spark.read.option("inferschema", "true").option("delimiter", delimiter).option("header", "true").csv(s3_input)
        df_delta = df_input.withColumn("fch_audit", current_timestamp())

        df_final = df_delta.write \
            .format("parquet") \
            .option("compression", "snappy") \
            .option("path", dest_path) \
            .mode("overwrite")

        if len(part_colum) > 0:
            df_final.partitionBy(part_colum)

        if len(target_tbl) > 0 and len(sch_target) > 0:
            df_final.saveAsTable('{}'.format(dest_tab))
        else:
            df_final.save()

        spark.stop()
        logger.info("Execution without CDC finished")



if __name__ == '__main__':

    # Obtiene los parametros de entrada
    s3_target = args['s3_target']
    dict_config = json.loads(args['dict_config'])
    ssm_client = boto3.client("ssm")
    dynamodb_cdc_table = ssm_client.get_parameter(Name='/SDLF/Dynamodb/MergeTable')['Parameter']['Value']
    key = dict_config.get('key')
    ori_bucket =  dict_config.get('bucket')
    ori_s3_path = 's3://' + ori_bucket +'/' + key
    table_key =  '/'.join(key.split('/')[:3]).replace('/','.').lower()
    
    dict_param = get_detail(table_key, dynamodb_cdc_table)
    
    if dict_param is not None:
        run_cdc(ori_s3_path, s3_target, dict_param)
    else:
        logger.info("Input wasn't defined")
    
    job.commit()