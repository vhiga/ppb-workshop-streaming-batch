import argparse
import json
import uuid

import boto3
from faker import Faker

client = boto3.client("kinesis")


def send_simple_data(stream_name):
    fake = Faker()
    x = fake.pyint()

    data = {
        "table_pk": 1,
        "country": "CO",
        "store": "100",
        "amount": 1000,
        "quantity": 10,
        "extra_field": "203",
        "date_dt": "2023-07-20",
    }

    while True:
        data["table_pk"] = x
        data["country"] = fake.random_element(elements=("US", "AR", "CO", "MX", "CL", "CO"))
        data["date_dt"] = fake.date_this_month().isoformat()
        data["quantity"] = fake.pyint()
        data["amount"] = fake.pyint()
        data["store"] = fake.random_element(elements=("100", "100", "200", "201", "400"))
        x = x + 1
        response = client.put_record(
            StreamName=stream_name, Data=json.dumps(data), PartitionKey=str(uuid.uuid4())
        )
        print(response)


def send_order_review_data(stream_name):
    fake = Faker()
    x = fake.pyint()

    data = {
        "deliveryid": 100,
        "date_dt": "2023-07-20",
        "order": {"storeid": 123, "amount": 400, "tax": 40, "quantity": 10},
        "delivery": {"store_time": 400, "delivery_time": 600, "type": "A", "provider": "X"},
        "customer": {"id": 5000, "lastname": "Stefy", "firstname": "Garcia", "rating": 4},
    }

    while True:
        data["deliveryid"] = x
        data["date_dt"] = fake.date_this_month().isoformat()

        data["order"]["storeid"] = fake.pyint()
        data["order"]["amount"] = fake.pyint()
        data["order"]["tax"] = fake.pyint()
        data["order"]["quantity"] = fake.pyint()

        data["delivery"]["store_time"] = fake.pyint()
        data["delivery"]["delivery_time"] = fake.pyint()
        data["delivery"]["type"] = fake.random_element(elements=("A", "B", "C", "D", "E"))
        data["delivery"]["provider"] = fake.random_element(elements=("X", "Y", "X"))

        data["customer"]["id"] = fake.pyint()
        data["customer"]["lastname"] = fake.first_name()
        data["customer"]["firstname"] = fake.last_name()
        data["customer"]["rating"] = fake.pyint()

        x = x + 1
        response = client.put_record(
            StreamName=stream_name, Data=json.dumps(data), PartitionKey=str(uuid.uuid4())
        )
        print(response)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-s", "--stream_name", required=True, help="Stream Name")
    args = vars(ap.parse_args())
    stream_name = args["stream_name"]

    if stream_name == "ppb-simple-table-stream":
        send_simple_data(stream_name)
    elif stream_name == "ppb-order-review-table-stream":
        send_order_review_data(stream_name)
    else:
        raise Exception("Stream doesn't exist")


if __name__ == "__main__":
    main()
