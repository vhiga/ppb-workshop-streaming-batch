from typing import Any, Dict, List

from pyspark.sql import DataFrame as SparkDataFrame


class Entity:
    """
    Modeling a Physical Catalog Entity.
    To be persisted in a 3NF Model.
    """

    def __init__(
        self,
        team_name: str = None,
        dataset: str = None,
        description: str = "default description",
        table_name: str = None,
        database_name: str = None,
        database_sublayer: str = None,
        storage_bucket: str = None,
        primary_key_column_name: str = None,
        sort_key_column_name: str = None,
        partitions_columns: List[str] = None,
        hudi_write_configs: Dict[str, str] = None,
        spark_configs: Dict[str, str] = None,
        dataframe: SparkDataFrame = None,
    ):
        self.team_name = team_name
        self.dataset = dataset
        self.description = description
        self.table_name = table_name
        self.database_name = database_name
        self.database_sublayer = database_sublayer
        self.storage_bucket = storage_bucket
        self.primary_key_column_name = primary_key_column_name
        self.sort_key_column_name = sort_key_column_name
        self.partitions_columns = partitions_columns
        self.hudi_write_configs = hudi_write_configs
        self.spark_configs = spark_configs
        self.dataframe = dataframe

    def to_dict(self) -> Dict[str, Any]:
        res = {
            "team_name": self.team_name,
            "table_name": self.table_name,
            "dataset": self.dataset,
            "description": self.description,
            "database_name": self.database_name,
            "database_sublayer": self.database_sublayer,
            "storage_bucket": self.storage_bucket,
            "primary_key_column_name": self.primary_key_column_name,
            "sort_key_column_name": self.sort_key_column_name,
            "partitions_columns": self.partitions_columns,
            "hudi_write_configs": self.hudi_write_configs,
            "spark_configs": self.spark_configs,
            "spark_dataframe": self.dataframe,
        }
        return res

    def to_string(self) -> str:
        return str(self.to_dict())

    def __str__(self) -> str:
        return self.to_string()

    def __repr__(self) -> str:
        return self.to_string()
