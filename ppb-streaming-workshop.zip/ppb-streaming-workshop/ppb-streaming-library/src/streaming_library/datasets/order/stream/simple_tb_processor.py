from typing import Dict

from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.functions import col
from pyspark.sql.types import DecimalType, IntegerType, StringType, TimestampType
from streaming_library.common.catalog.entity import Entity
from streaming_library.common.stream.processor import StreamProcessor
from streaming_library.common.stream.stream_utils import (
    add_dlk_processing_dttm_to_dataframe,
    get_hudi_config,
)
from streaming_library.datasets.order.stream.parameters import (
    ProcessingParameters,
    SimpleTable,
)


class SimpleTableStreamProcessor(StreamProcessor):
    def parse(self, input_dataframe: SparkDataFrame) -> Dict[str, Entity]:
        # parse (enrich, cascade, enforce data types, mask, remove extra columns)
        self.logger.info("Starting parse for SimleTable stream processor")
        table_name = SimpleTable.name
        final_df = self.get_simple_table_dataframe(input_dataframe=input_dataframe)

        entity_hudi_configs = get_hudi_config(
            team_name=self.team_name,
            table_name=table_name,
            analytics_bucket=self.analytics_db_bucket_name,
            hudi_params=ProcessingParameters.HUDI_CONFIGS,
        )
        parsed_entity = Entity(
            table_name=table_name,
            database_name=self.curated_db_name,
            dataframe=final_df,
            hudi_write_configs=entity_hudi_configs,
        )

        result = {
            f"{table_name}:nonmasked": parsed_entity,
        }

        return result

    def get_simple_table_dataframe(self, input_dataframe: SparkDataFrame) -> SparkDataFrame:
        # extend
        df = add_dlk_processing_dttm_to_dataframe(input_dataframe)

        # enforce data types
        df = df.withColumn("table_pk", col("table_pk").cast(IntegerType()))
        df = df.withColumn("country", col("country").cast(StringType()))
        df = df.withColumn("store", col("store").cast(StringType()))
        df = df.withColumn("amount", col("amount").cast(DecimalType(15, 2)))
        df = df.withColumn("quantity", col("quantity").cast(IntegerType()))
        df = df.withColumn("__src_timestamp", col("__src_timestamp").cast(TimestampType()))
        df = df.withColumn("date_dt", col("date_dt").cast(StringType()))

        columns = [
            "table_pk",
            "country",
            "store",
            "dlk_processing_dttm",
            "quantity",
            "amount",
            "__src_timestamp",
            "date_dt",
        ]

        # sort and prune
        df = df.select(*columns)

        return df
