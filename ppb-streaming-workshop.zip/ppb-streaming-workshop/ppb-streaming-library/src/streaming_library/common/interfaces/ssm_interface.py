import datetime as dt
import os
from datetime import datetime, timedelta, tzinfo

import boto3
from boto3.dynamodb.conditions import Attr, Key
from botocore.exceptions import ClientError
from streaming_library.base.support import init_logger


class SSMInterface:
    def __init__(self, configuration, log_level=None, ssm_resource=None):
        self.log_level = log_level or os.getenv("LOG_LEVEL", "INFO")
        self._logger = init_logger(__name__, self.log_level)
        self.ssm_resource = ssm_resource or boto3.client("ssm")
        self._config = configuration

    def get_ssm_parameter(self, key):
        return self._config.get_ssm_param(key)
