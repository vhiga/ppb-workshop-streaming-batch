import os
from typing import Any, Optional

import boto3
from streaming_library.base.support import init_logger

from .base_config import BaseConfig


class SSMConfiguration(BaseConfig):
    def __init__(self, log_level=None, ssm_interface=None):
        """
        Complementary SSM config stores the parameters required to operate the data lake
        :param log_level: level the class logger should log at
        :param ssm_interface: ssm interface, normally boto, to read parameters from parameter store
        """
        self.log_level = log_level or os.getenv("LOG_LEVEL", "INFO")
        self._logger = init_logger(__name__, self.log_level)
        self._ssm = ssm_interface or boto3.client("ssm")
        super().__init__(self.log_level, self._ssm)

    def get_ssm_param(self, key):
        return self._get_ssm_param(key)


class CodeArtifactConfiguration(BaseConfig):
    _team_name: str
    _domain_name: str
    _domain_owner: str
    _repository_name: str

    def __init__(
        self, team: str, ssm_client: Optional[Any] = None, log_level: Optional[str] = None
    ) -> None:
        log_level = log_level or os.getenv("LOG_LEVEL", "INFO")
        ssm_client = ssm_client or boto3.client("ssm")
        super().__init__(log_level=log_level, ssm_interface=ssm_client)
        self._team_name = team
        self._fetch_from_ssm()

    def _fetch_from_ssm(self):
        self._domain_name = None
        self._domain_owner = None
        self._repository_name = None

    @property
    def domain_name(self) -> str:
        """
        Returns the CodeArtifact domain name for a Team.

        Returns
        -------
        str
            Parameter value representing a CodeArtifact domain name.
        """
        if not self._domain_name:
            self._domain_name = self._get_ssm_param("/CodeArtifact/Domain/Name")
        return self._domain_name

    @property
    def domain_owner(self) -> str:
        """
        Returns the CodeArtifact domain owner for a Team.

        Returns
        -------
        str
            Parameter value representing a CodeArtifact domain owner.
        """
        if not self._domain_owner:
            self._domain_owner = self._get_ssm_param("/CodeArtifact/Domain/Owner")
        return self._domain_owner

    @property
    def repository_name(self) -> str:
        """
        Returns the CodeArtifact repository name for a Team.

        Returns
        -------
        str
            Parameter value representing a CodeArtifact repository name.
        """
        if not self._repository_name:
            self._repository_name = self._get_ssm_param("/CodeArtifact/Repository")
        return self._repository_name
